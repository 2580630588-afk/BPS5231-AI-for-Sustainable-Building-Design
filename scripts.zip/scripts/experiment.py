"""Final-stage deterministic geometry, paired experiment and EnergyPlus runner."""
from pathlib import Path
import math,json,csv,copy,re,hashlib,subprocess,sqlite3,time,argparse,concurrent.futures,datetime
from legacy import read_idf,write_idf,save_csv,read_csv,area
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw';RES=ROOT/'results';IDF=ROOT/'data/idf'
PRODUCTS={'SN75':{'u':1.,'shgc':.40,'vt':.75},'SN7035':{'u':1.,'shgc':.35,'vt':.70},'SN4023':{'u':1.,'shgc':.23,'vt':.40}}
Q='Zone Ideal Loads Supply Air Total Cooling Energy'
def signed(v):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(v,v[1:]+v[:1]))/2

def polygon(shape,A):
 if shape.startswith('rect'):r=float(shape[4:]);v=[(0,0),(r,0),(r,1),(0,1)]
 elif shape=='L':v=[(0,0),(3,0),(3,1),(1,1),(1,3),(0,3)]
 elif shape=='Lwide':v=[(0,0),(3,0),(3,1.3),(1.3,1.3),(1.3,3),(0,3)]
 else:
  n={'triangle':3,'pentagon':5,'hexagon':6}.get(shape,int(shape[6:]) if shape.startswith('circle') else 0)
  v=[(math.cos(2*math.pi*k/n),math.sin(2*math.pi*k/n)) for k in range(n)]
 f=math.sqrt(A/signed(v));v=[(x*f,y*f) for x,y in v];mx=min(x for x,y in v);my=min(y for x,y in v)
 return [(x-mx,y-my) for x,y in v]
def inside(p,v):
 x,y=p;c=False
 for (ax,ay),(bx,by) in zip(v,v[1:]+v[:1]):
  if (ay>y)!=(by>y) and x<(bx-ax)*(y-ay)/(by-ay)+ax:c=not c
 return c

def triangles(v):
 # Ear clipping avoids nonconvex floor/roof surfaces for the L plans.
 idx=list(range(len(v)));out=[]
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 while len(idx)>3:
  for j,b in enumerate(idx):
   a=idx[j-1];c=idx[(j+1)%len(idx)]
   if cross(v[a],v[b],v[c])<=1e-9:continue
   if any(all(cross(q,r,v[k])>=-1e-9 for q,r in [(v[a],v[b]),(v[b],v[c]),(v[c],v[a])]) for k in idx if k not in [a,b,c]):continue
   out.append([v[a],v[b],v[c]]);idx.pop(j);break
  else:raise ValueError('Cannot triangulate')
 out.append([v[k] for k in idx]);assert abs(sum(signed(t) for t in out)-signed(v))<1e-6
 return out

def geom(row):
 v=polygon(row['shape'],float(row['area']));ang=math.radians(float(row['orientation']));P=0;exp=[0.]*8
 for a,b in zip(v,v[1:]+v[:1]):
  dx=b[0]-a[0];dy=b[1]-a[1];l=math.hypot(dx,dy);P+=l
  # Building north rotation is clockwise. Outward normal of CCW edge.
  az=math.atan2(dy,-dx)+ang
  for k in range(8):exp[k]+=l*max(0,math.cos(az-k*math.pi/4))
 A=float(row['area']);xs=[x for x,y in v];ys=[y for x,y in v]
 return {'perimeter':P,'wall_floor':3*P/A,'compactness':4*math.pi*A/P**2,'bbox_fill':A/((max(xs)-min(xs))*(max(ys)-min(ys))),**{f'exposure{k}':e/P for k,e in enumerate(exp)}}
def make_case(shape,A,o,w,product,shade,group,**kw):
 row=dict(shape=shape,area=A,orientation=o,wwr=w,product=product,shade=shade,ach=.6,schedule='base',rh='70',daylight=0,zoning='single',group=group,**PRODUCTS[product]);row.update(kw)
 row['context']=f'{shape}_a{A}_o{o}_w{w}_{row["ach"]}_{row["schedule"]}_{row["rh"]}_{row["daylight"]}_{row["zoning"]}'
 row['case_id']=row['context']+'_'+product+'_d'+str(shade);return row

def design():
 rows=[]
 def add(shapes,areas,orientations,wwrs,group,**kw):
  for sh in shapes:
   for A in areas:
    for o in orientations:
     for w in wwrs:
      for pr in PRODUCTS:
       for d in [0,.6]:rows.append(make_case(sh,A,o,w,pr,d,group,**kw))
 add(['rect1','rect2','rect4'],[600,900,1200],[0,45,90,135],[.2,.4,.6],'train_rectangle')
 add(['L','triangle','pentagon','hexagon','circle24'],[900],[0,45,90,135],[.2,.4,.6],'train_family')
 add(['rect1.5','rect3'],[900],[15,75],[.3,.5],'test_ratio_interpolation')
 add(['rect5'],[900],[15,75],[.3,.5],'test_ratio_extrapolation')
 add(['rect2'],[750,1050,1500],[15,75],[.3,.5],'test_area')
 add(['Lwide','triangle','pentagon','hexagon','circle24'],[750,1050],[15,75],[.3,.5],'test_family_area')
 for kw in [dict(ach=.3),dict(ach=1.2),dict(schedule='extended'),dict(rh='60'),dict(rh='none')]:
  add(['rect2','L','triangle','pentagon','hexagon','circle24'],[900],[0],[.4],'sensitivity',**kw)
 add(['circle12','circle48'],[900],[0],[.4],'circle_convergence')
 add(['rect2'],[900],[0,45],[.2,.4,.6],'daylight_application',daylight=1)
 add(['rect1','rect2','rect4'],[900],[0],[.4],'zoning_check',zoning='five')
 add(['rect1.5','rect3','rect5','Lwide'],[900],[0,45],[.2,.4,.6],'diagnostic_shape_only')
 add(['rect2','L','triangle','pentagon','hexagon','circle24'],[750,1050,1500],[0],[.4],'diagnostic_area_only')
 assert len({r['case_id'] for r in rows})==len(rows)
 return rows

def build(r):
 base=read_idf(RAW/'office_original.idf')
 if r['zoning']=='five':
  from legacy import generate
  ar=float(r['shape'][4:]);old={'length_m':math.sqrt(900*ar),'width_m':math.sqrt(900/ar),'orientation_deg':r['orientation'],'wwr':r['wwr'],'shgc':r['shgc'],'overhang_m':r['shade']}
  obs,qa=generate(base,old)
  obs=[o for o in obs if not o[0].startswith(('WaterUse:','WaterHeater:','Plant','Branch','Pipe:','Pump:','Connector:','SetpointManager:')) and o[0] not in ['Sizing:Plant','Site:WaterMainsTemperature']]
  for ob in obs:
   if ob[0]=='WindowMaterial:SimpleGlazingSystem':ob[2:]=[str(r['u']),str(r['shgc']),str(r['vt'])]
   if ob[0]=='BuildingSurface:Detailed':
    if ob[2]=='Floor':ob[3]='Generic Interior Floor'
    elif ob[2]=='Roof':ob[3]='Generic Roof'
    elif ob[6]=='Outdoors':ob[3]='Generic Exterior Wall'
  return obs,{'zones':5,'sensors':0,'area_check':900,'wwr_check':r['wwr']}
 # Rebuild a single well-mixed open-plan thermal zone, consistent across all families.
 keep={'Version','Timestep','Material','Material:NoMass','WindowMaterial:Gas','WindowMaterial:Glazing','Construction'}
 obs=[copy.deepcopy(o) for o in base if o[0] in keep or o[0].startswith('Schedule')]
 for ob in obs:
  if ob[0]=='Schedule:Day:Interval' and not ob[2]:ob[2]='Fractional'
  if ob[0] in ['Schedule:Year','Schedule:Constant'] and not ob[2]:ob[2]='Fractional'
  if r['schedule']=='extended' and ob[0]=='Schedule:Day:Interval' and ob[1]=='Schedule Day 1':ob[4:]=['07:00','0','20:00','.75','24:00','0']
  if ob[0]=='Schedule:Day:Interval' and ob[1]=='Office Setpoint_DeHumidSetp_Day Schedule':ob[-1]='60' if r['rh']=='60' else '70'
 # Remove original glazing construction and replace the referenced material.
 obs += [['WindowMaterial:SimpleGlazingSystem','Simple Glazing',str(r['u']),str(r['shgc']),str(r['vt'])]]
 for ob in obs:
  if ob[0]=='Construction' and ob[1]=='Double Glazing with Low Emission Coating':ob[2:]=['Simple Glazing']
 obs += [['Building','Final Study',str(r['orientation']),'City','.04','.4','FullExteriorWithReflections','25','6'],['GlobalGeometryRules','UpperLeftCorner','Counterclockwise','Relative','Relative','Relative'],['Site:Location','Singapore IWEC','1.37','103.98','8','16'],['SimulationControl','No','No','No','No','Yes','No'],['RunPeriod','Annual','1','1','2006','12','31','2006','Sunday','No','No','No','Yes','Yes'],['Zone','Office','0','0','0','0','1','1','3','Autocalculate','Autocalculate'],['HeatBalanceAlgorithm','ConductionTransferFunction']]
 for typ in ['People','Lights','ElectricEquipment']:
  ob=copy.deepcopy(next(o for o in base if o[0]==typ));ob[2]='Office';obs.append(ob)
 obs += [['Schedule:Constant','ControlType','Office_Shoebox_1_ffcd7f28 Thermostat Schedule Type Limits','4'],['ThermostatSetpoint:DualSetpoint','Setpoint','Heating Setpoint','Cooling Setpoint'],['ZoneControl:Thermostat','Thermostat','Office','ControlType','ThermostatSetpoint:DualSetpoint','Setpoint'],['ZoneControl:Humidistat','Humidity','Office','Office Setpoint_HumidSetp','Office Setpoint_DeHumidSetp'],['DesignSpecification:OutdoorAir','OA','Sum','0','0','0',str(r['ach']),'Building Occupancy'],['ZoneHVAC:EquipmentConnections','Office','Equipment','Supply','Exhaust','Air'],['ZoneHVAC:EquipmentList','Equipment','SequentialLoad','ZoneHVAC:IdealLoadsAirSystem','Ideal','1','1','','']]
 ideal=copy.deepcopy(next(o for o in base if o[0]=='ZoneHVAC:IdealLoadsAirSystem'));ideal[1:6]=['Ideal','','Supply','Exhaust',''];ideal[10:16]=['NoLimit','','','NoLimit','',''];ideal[21]='OA';ideal[25:28]=['None','0','0']
 if r['rh']=='none':ideal[18]='None';ideal[20]='None'
 obs.append(ideal)
 v=polygon(r['shape'],r['area']);wall_area=win_area=0
 def surface(name,typ,cons,pts,boundary='Adiabatic'):
  return ['BuildingSurface:Detailed',name,typ,cons,'Office','',boundary,'','SunExposed' if boundary=='Outdoors' else 'NoSun','WindExposed' if boundary=='Outdoors' else 'NoWind','Autocalculate',str(len(pts))]+[f'{z:.8f}' for pt in pts for z in pt]
 for i,t in enumerate(triangles(v)):
  obs.append(surface('Floor'+str(i),'Floor','Generic Interior Floor',[(x,y,0) for x,y in t[::-1]]))
  obs.append(surface('Roof'+str(i),'Roof','Generic Roof',[(x,y,3) for x,y in t]))
 for i,(a,b) in enumerate(zip(v,v[1:]+v[:1])):
  name='Wall'+str(i);pts=[(*b,3),(*a,3),(*a,0),(*b,0)] # cross points outward for CCW plan
  # Correct winding: start at a top, a bottom, b bottom, b top.
  pts=[(*a,3),(*a,0),(*b,0),(*b,3)]
  obs.append(surface(name,'Wall','Generic Exterior Wall',pts,'Outdoors'))
  center=[sum(p[k] for p in pts)/4 for k in range(3)];f=math.sqrt(r['wwr']);wp=[[center[k]+f*(p[k]-center[k]) for k in range(3)] for p in pts]
  obs.append(['FenestrationSurface:Detailed','Win'+str(i),'Window','Double Glazing with Low Emission Coating',name,'','','','','4']+[f'{z:.8f}' for pt in wp for z in pt])
  wall_area+=area(pts);win_area+=area(wp)
  if r['shade']:
   dx=b[0]-a[0];dy=b[1]-a[1];l=math.hypot(dx,dy);normal=(dy/l,-dx/l);a1,b1=wp[0],wp[3]
   ext=lambda p:[p[0]+normal[0]*r['shade'],p[1]+normal[1]*r['shade'],p[2]]
   obs.append(['Shading:Zone:Detailed','Shade'+str(i),name,'','4']+[f'{z:.8f}' for pt in [a1,b1,ext(b1),ext(a1)] for z in pt])
 sensors=0
 if r['daylight']:
  xmax=max(x for x,y in v);ymax=max(y for x,y in v);controls=['Daylighting:Controls','Daylight','Office','SplitFlux','','Continuous','.3','.2','1','1','','0','22','']
  for x in [.1,.5,.9]:
   for y in [.1,.5,.9]:
    if inside((x*xmax,y*ymax),v):
     name=f'Sensor{sensors}';obs.append(['Daylighting:ReferencePoint',name,'Office',str(x*xmax),str(y*ymax),'.8']);controls += [name,'0','300'];sensors+=1
  obs.append(controls)
  obs.extend([['Output:Variable','*',f'Daylighting Reference Point {k+1} Illuminance','Hourly'] for k in range(sensors)])
 obs += [['Output:Variable','*',Q,'Hourly'],['Output:SQLite','SimpleAndTabular']]
 assert abs(signed(v)-r['area'])<1e-6
 assert abs(win_area/wall_area-r['wwr'])<1e-8
 return obs,{'zones':1,'sensors':sensors,'area_check':signed(v),'wwr_check':win_area/wall_area}

def prepare():
 rows=design();checks=[]
 for r in rows:
  obs,qa=build(r);write_idf(IDF/(r['case_id']+'.idf'),obs);checks.append(dict(case_id=r['case_id'],**qa))
 save_csv(ROOT/'data/design_matrix.csv',rows);save_csv(RES/'geometry_checks.csv',checks)
 (ROOT/'data/products.json').write_text(json.dumps(PRODUCTS,indent=2))
 if not (ROOT/'data/protocol.json').exists():(ROOT/'data/protocol.json').write_text(json.dumps({'frozen_before_runs':True,'cases':len(rows),'training_groups':['train_rectangle','train_family'],'external_test_groups':sorted({r['group'] for r in rows if r['group'].startswith('test')}),'primary_target':'supply-air cooling thermal intensity','daylight':'9-point DA300 at occupied weekday hours, rectangle application only, no compliance or spatial DA claim','circle':'equal-area 24-gon with 12/48-gon convergence','sensitivity':'one factor at a time, exploratory ranges not compliance limits','zoning':'one well-mixed open-plan zone; five-zone bridge audit','products_source':'Guardian Coated Glass 2025, p2, double 6-16-4 argon90; g used as nominal SHGC in SimpleGlazing approximation'},indent=2))
 print('Prepared',len(rows),'cases',flush=True)

def runone(r,exe,keep_sql=False):
 for k in ['area','orientation','wwr','shade','ach','u','shgc','vt']:r[k]=float(r[k])
 r['daylight']=int(r['daylight']);folder=RES/'runs'/r['case_id'];folder.mkdir(parents=True,exist_ok=True);cache=folder/'record.json'
 model=IDF/(r['case_id']+'.idf');weather=RAW/'singapore_iwec.epw';sig=hashlib.sha256(model.read_bytes()+weather.read_bytes()+Path(exe).read_bytes()).hexdigest()
 if cache.exists():
  prev=json.loads(cache.read_text(encoding='utf-8-sig'));
  if prev.get('input_hash')==sig:
   prev.update(geom(r));return prev
 start=time.perf_counter();p=subprocess.run([str(exe),'-w',str(weather),'-d',str(folder),str(model)],capture_output=True,text=True,timeout=300)
 err=(folder/'eplusout.err').read_text(errors='replace') if (folder/'eplusout.err').exists() else p.stderr
 if p.returncode or '** Severe **' in err:raise RuntimeError(r['case_id']+'\n'+err[-7000:])
 with sqlite3.connect(folder/'eplusout.sql') as db:
  hrs=db.execute('''SELECT r.TimeIndex,SUM(r.Value),COUNT(*) FROM ReportData r JOIN ReportDataDictionary d USING(ReportDataDictionaryIndex) JOIN Time t USING(TimeIndex) JOIN EnvironmentPeriods e USING(EnvironmentPeriodIndex) WHERE d.Name=? AND d.ReportingFrequency='Hourly' AND COALESCE(t.WarmupFlag,0)=0 AND e.EnvironmentType=3 GROUP BY r.TimeIndex ORDER BY r.TimeIndex''',(Q,)).fetchall()
  assert len(hrs)==8760 and all(n==(5 if r['zoning']=='five' else 1) for _,_,n in hrs)
  da='';da_min='';npoints=0
  if r['daylight']:
   rr=db.execute('''SELECT d.Name,t.Month,t.Day,t.Hour,r.Value FROM ReportData r JOIN ReportDataDictionary d USING(ReportDataDictionaryIndex) JOIN Time t USING(TimeIndex) JOIN EnvironmentPeriods e USING(EnvironmentPeriodIndex) WHERE d.Name LIKE 'Daylighting Reference Point % Illuminance' AND d.ReportingFrequency='Hourly' AND COALESCE(t.WarmupFlag,0)=0 AND e.EnvironmentType=3''').fetchall()
   groups={}
   for name,month,day,hour,value in rr:
    if datetime.date(2006,month,day).weekday()<5 and 10<=hour<=18:groups.setdefault(name,[]).append(value)
   assert len(groups)==9,(r['case_id'],len(groups),db.execute("select distinct Name from ReportDataDictionary").fetchall())
   vals=[sum(v>=300 for v in vv)/len(vv)*100 for vv in groups.values()];da=sum(vals)/len(vals);da_min=min(vals);npoints=len(vals)
 db.close()
 annual=sum(v for _,v,_ in hrs)/3.6e6
 rec={**r,**geom(r),'cooling_kwh_th':annual,'cooling_kwh_th_m2':annual/r['area'],'peak_kw_th':max(v for _,v,_ in hrs)/3.6e6,'hours':8760,'da300_mean_pct':da,'da300_min_pct':da_min,'daylight_points':npoints,'warnings':err.count('** Warning **'),'runtime_seconds':time.perf_counter()-start,'input_hash':sig}
 cache.write_text(json.dumps(rec,indent=2))
 # Compact reproducibility archive retains IDF, err and record. SQL can be regenerated.
 if not keep_sql:
  for f in folder.iterdir():
   if f.name not in ['record.json','eplusout.err']:f.unlink()
 return rec

def run(exe,workers,limit,group):
 version=subprocess.check_output([str(exe),'--version'],text=True).strip()
 if '24.2' not in version:raise RuntimeError('EnergyPlus 24.2 is required for these models')
 (RES/'engine_provenance.json').write_text(json.dumps({'version':version,'engine_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()},indent=2))
 rows=read_csv(ROOT/'data/design_matrix.csv')
 if group:rows=[r for r in rows if r['group'] in group.split(',')]
 if limit:rows=rows[:limit]
 start=time.perf_counter();records=[];failed=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
  futures={pool.submit(runone,r,exe):r for r in rows}
  for f in concurrent.futures.as_completed(futures):
   try:records.append(f.result())
   except Exception as e:failed.append(str(e));print('FAILED',str(e)[:1000],flush=True)
   if (len(records)+len(failed))%25==0:print('Completed',len(records),'failed',len(failed),'elapsed',round(time.perf_counter()-start),flush=True)
 (RES/'failures.json').write_text(json.dumps(failed,indent=2))
 allrec=[json.loads(p.read_text(encoding='utf-8-sig')) for p in (RES/'runs').glob('*/record.json')]
 if allrec:save_csv(RES/'simulation_results.csv',sorted(allrec,key=lambda r:r['case_id']))
 (RES/'last_run.json').write_text(json.dumps({'wall_seconds':time.perf_counter()-start,'workers':workers,'requested':len(rows),'completed':len(records),'failed':len(failed)},indent=2))
 print('Finished',len(records),'failures',len(failed),flush=True)
 if failed:raise SystemExit(1)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['prepare','run']);ap.add_argument('--energyplus');ap.add_argument('--workers',type=int,default=4);ap.add_argument('--limit',type=int);ap.add_argument('--group');a=ap.parse_args()
 if a.command=='prepare':prepare()
 else:run(a.energyplus,a.workers,a.limit,a.group)
