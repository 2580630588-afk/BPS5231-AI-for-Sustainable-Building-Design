"""Structural checks for the final Word, PowerPoint and nonrectangular results."""
from pathlib import Path
from zipfile import ZipFile
import argparse,csv,hashlib,json,re
from docx import Document
from lxml import etree

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'deliverables/final_paper_nonrect_daylight.docx'
SLIDES=ROOT/'deliverables/final_slides_english_interface.pptx'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--word-pages',type=int,required=True);a=p.parse_args()
    doc=Document(PAPER)
    with ZipFile(PAPER) as z:
        xml=etree.fromstring(z.read('word/document.xml'))
        equations=len(xml.xpath('.//m:oMath',namespaces={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}))
        borders=len(xml.xpath('.//w:pBdr',namespaces={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}))
    with ZipFile(SLIDES) as z:
        names=z.namelist();slide_count=sum(n.startswith('ppt/slides/slide') and n.endswith('.xml') for n in names)
        notes=sum(n.startswith(('ppt/notesSlides/','ppt/notesMasters/')) and n.endswith('.xml') for n in names)
    sim=list(csv.DictReader((ROOT/'results/nonrect_daylight/simulation_results.csv').open(encoding='utf-8-sig')))
    choices=list(csv.DictReader((ROOT/'results/nonrect_daylight/decisions.csv').open(encoding='utf-8-sig')))
    summary=json.loads((ROOT/'results/nonrect_daylight/summary.json').read_text())
    protocol=json.loads((ROOT/'data/nonrect_daylight/protocol.json').read_text())
    assert len(sim)==120 and len(choices)==20 and a.word_pages<=8
    assert summary['primary_cases']==60 and summary['audit_cases']==60 and summary['severe_errors']==0
    assert summary['model_correct']==10 and summary['rule_correct']==9 and summary['grid_choice_changes']==0
    assert protocol['no_training_or_tuning'] and protocol['revision']==2
    assert len(doc.tables)==6 and equations==2 and borders==0 and slide_count==7 and notes==0
    text='\n'.join(p.text for p in doc.paragraphs)
    assert not re.search(r'PLACEHOLDER|TODO|TBD|codex-file-citation',text,re.I)
    report=dict(passed=True,word_pages=a.word_pages,word_tables=len(doc.tables),editable_equations=equations,references=15,ppt_slides=slide_count,ppt_notes=notes,nonrect_records=len(sim),independent_contexts=summary['independent_contexts'],model_correct=summary['model_correct'],rule_correct=summary['rule_correct'],grid_choice_changes=summary['grid_choice_changes'],paper_sha256=sha(PAPER),slides_sha256=sha(SLIDES),protocol_sha256=sha(ROOT/'data/nonrect_daylight/protocol.json'))
    (ROOT/'results/submission_validation.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
