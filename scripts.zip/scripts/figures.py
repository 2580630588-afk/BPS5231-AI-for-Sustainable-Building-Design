"""Scientific figures generated only from completed simulation and evaluation tables."""
from pathlib import Path
import json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from experiment import ROOT,RES,read_csv,polygon
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
F=RES/'figures';F.mkdir(exist_ok=True)
S=json.loads((RES/'summary.json').read_text(encoding='utf-8-sig'));rows=read_csv(RES/'simulation_results.csv');metrics=read_csv(RES/'pooled_metrics.csv')
fig,axes=plt.subplots(2,4,figsize=(10,5))
for ax,shape in zip(axes.flat,['rect1','rect2','rect4','L','triangle','pentagon','hexagon','circle24']):
 v=polygon(shape,900);x,y=zip(*(v+[v[0]]));ax.fill(x,y,color='#d0e9e8',edgecolor='#087f8c',linewidth=1.5);ax.set_aspect('equal');ax.set_xlim(-3,65);ax.set_ylim(-3,45);ax.set_title(shape);ax.set_xticks([]);ax.set_yticks([])
fig.suptitle('Equal-area examples: 900 m², height 3 m');fig.tight_layout();fig.savefig(F/'plan_shapes.png');plt.close(fig)
mods=['strategy_mean','interpolation','ridge','forest'];names=['Strategy mean','5-NN interpolation','Polynomial Ridge','Random forest'];x=np.arange(4)
fig,ax=plt.subplots(figsize=(8,4))
for j,(scheme,label,c) in enumerate([('grouped_cv','Grouped CV','#6b8494'),('rectangle_transfer','Rectangle-trained external','#b76832'),('expanded_transfer','Expanded-trained external','#087f8c')]):
 vals=[float(next(r for r in metrics if r['scheme']==scheme and r['model']==m and r['subset']=='all')['mae']) for m in mods];ax.bar(x+(j-1)*.24,vals,width=.24,label=label,color=c)
ax.set_xticks(x,names,rotation=10);ax.set_ylabel('Cooling MAE [kWh thermal/(m² year)]');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(F/'prediction_comparison.png');plt.close(fig)
pr=read_csv(RES/'predictions.csv');selected=S['selected_by_grouped_cv'];p=[r for r in pr if r['model']==selected and r['scheme']=='expanded_transfer'];fig,ax=plt.subplots(figsize=(6,4))
for g in sorted(set(r['group'] for r in p)):
 rr=[r for r in p if r['group']==g];ax.scatter([float(r['actual']) for r in rr],[float(r['predicted']) for r in rr],s=14,alpha=.6,label=g.replace('test_',''))
lo=min(float(r['actual']) for r in p);hi=max(float(r['actual']) for r in p);ax.plot([lo,hi],[lo,hi],'k--',lw=1);ax.set_xlabel('Simulated cooling intensity');ax.set_ylabel('Predicted cooling intensity');ax.legend(fontsize=7);fig.tight_layout();fig.savefig(F/'external_predictions.png');plt.close(fig)
sens=read_csv(RES/'sensitivity.csv');conditions=sorted(set(r['condition'] for r in sens));fig,axes=plt.subplots(1,2,figsize=(10,4))
for ax,key,label in zip(axes,['cooling_change','reduction_change_pp'],['Change in cooling intensity','Change in paired reduction [percentage points]']):
 vals=[[float(r[key]) for r in sens if r['condition']==c] for c in conditions];ax.boxplot(vals,tick_labels=[c.replace('ACH','').replace('_base_RH',' / RH').replace('_extended_RH',' / longer / RH') for c in conditions],showfliers=True);ax.axhline(0,color='#087f8c',lw=1);ax.set_ylabel(label);ax.tick_params(axis='x',rotation=30)
fig.tight_layout();fig.savefig(F/'sensitivity.png');plt.close(fig)
app=read_csv(RES/'design_application.csv');fig,ax=plt.subplots(figsize=(7,4))
for product,c in [('SN75','#6b8494'),('SN7035','#087f8c'),('SN4023','#b76832')]:
 rr=[r for r in app if r['product']==product];ax.scatter([float(r['cooling_kwh_th_m2']) for r in rr],[float(r['da300_mean_pct']) for r in rr],s=45,label=product,color=c)
ax.axhline(50,ls='--',color='black',label='Illustrative 50% screen');ax.set_xlabel('Cooling [kWh thermal/(m² year)]');ax.set_ylabel('Mean nine-point DA300 [% occupied hours]');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(F/'daylight_tradeoff.png');plt.close(fig)
curve=read_csv(RES/'learning_curve.csv');fig,ax=plt.subplots(figsize=(6,3.5));ax.plot([int(r['n_train']) for r in curve],[float(r['mae']) for r in curve],'o-',color='#087f8c');ax.set_xlabel('Training simulations');ax.set_ylabel('External cooling MAE');fig.tight_layout();fig.savefig(F/'learning_curve.png');plt.close(fig)
print('Saved six result figures.')
