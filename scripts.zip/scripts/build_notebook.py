"""Execute readable analysis cells in one Python namespace and save actual outputs."""
from pathlib import Path
import io,contextlib,traceback,sys
import nbformat
ROOT=Path(__file__).resolve().parents[1]
cells=[
nbformat.v4.new_markdown_cell('# Final study: reproducible analysis\n\nRun from the project root. The bundled simulation outcomes are sufficient for model evaluation. EnergyPlus is required only to regenerate physical simulations. Units throughout: cooling thermal demand, not electricity.'),
nbformat.v4.new_code_cell("from pathlib import Path\nimport sys, subprocess, json, csv\nROOT = Path.cwd()\nif not (ROOT / 'results/simulation_results.csv').exists():\n    raise RuntimeError('Open the notebook from the project root.')\nsys.path.insert(0, str(ROOT / 'scripts'))\nrows = list(csv.DictReader((ROOT / 'results/simulation_results.csv').open(encoding='utf-8-sig')))\nfrom collections import Counter\nprint('Completed simulations:', len(rows))\nprint(Counter(r['group'] for r in rows))"),
nbformat.v4.new_markdown_cell('## Refit fixed models and regenerate held-out predictions\nThe six strategies stay together in validation groups. Rotationally equivalent cases are grouped. Selection uses training CV only. The post-hoc diagnostic set remains separate.'),
nbformat.v4.new_code_cell("completed = subprocess.run([sys.executable, 'scripts/analyze.py'], cwd=ROOT, capture_output=True, text=True, check=True)\nprint(completed.stdout)"),
nbformat.v4.new_code_cell("metrics = list(csv.DictReader((ROOT/'results/pooled_metrics.csv').open(encoding='utf-8-sig')))\nfor r in metrics:\n    if r['subset']=='all':\n        print(r['scheme'], r['model'], 'MAE=', round(float(r['mae']), 4))"),
nbformat.v4.new_code_cell("effects = list(csv.DictReader((ROOT/'results/paired_metrics.csv').open(encoding='utf-8-sig')))\nfor r in effects:\n    if r['model']=='ridge':\n        print(r['scheme'], 'saving MAE:', round(float(r['saving_mae']), 4), 'reduction MAE (pp):', round(float(r['reduction_mae_pp']), 4))"),
nbformat.v4.new_code_cell("choices = list(csv.DictReader((ROOT/'results/design_choices.csv').open(encoding='utf-8-sig')))\nfor r in choices:\n    print(r['context'], 'unconstrained:', r['unconstrained_option'], 'screened:', r['screened_option'])\nprint('These thermal contexts occur in development data; zero regret is not independent recommendation validation.')"),
nbformat.v4.new_code_cell("completed = subprocess.run([sys.executable, 'scripts/verify.py'], cwd=ROOT, capture_output=True, text=True, check=True)\nprint(completed.stdout)"),
nbformat.v4.new_markdown_cell('## Interpretation\nDo not infer real-building accuracy from simulation consistency. The 9-point daylight screen is not sDA or compliance. Numerical geometric distance is not an uncertainty interval. The benchmark includes separate sequential EnergyPlus runs; reproduce it with scripts/benchmark.py and EnergyPlus 24.2.')]
cells.extend([nbformat.v4.new_markdown_cell('## Independent November follow-up\n30 new simulations remain separate from the original 1,890. Predictions were frozen before these runs. Both selectors use simulated daylight feasibility; the simple rule is a required comparator.'),nbformat.v4.new_code_cell("completed = subprocess.run([sys.executable, 'scripts/final_validation.py', 'analyze'], cwd=ROOT, capture_output=True, text=True, check=True)\nprint(completed.stdout)\nprint((ROOT/'results/final_validation/decisions.csv').read_text(encoding='utf-8-sig'))")])
cells.extend([nbformat.v4.new_markdown_cell('## Nonrectangular daylight extension\nFive shapes at 850 m² and 30°, with WWR 20% and 40%. There are 60 primary cases and 60 repetitions with a finer sampling grid. The latter are not independent physical contexts. Frozen predictions and sampling revisions are retained; neither follow-up is used for fitting or tuning.'),nbformat.v4.new_code_cell("completed = subprocess.run([sys.executable, 'scripts/nonrect_daylight.py', 'analyze'], cwd=ROOT, capture_output=True, text=True, check=True)\nprint(completed.stdout)\nprint((ROOT/'results/nonrect_daylight/decisions.csv').read_text(encoding='utf-8-sig'))")])
nb=nbformat.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'}})
import os
old=Path.cwd();os.chdir(ROOT);env={};count=0
try:
    for cell in nb.cells:
        if cell.cell_type!='code':continue
        count+=1;buf=io.StringIO()
        with contextlib.redirect_stdout(buf):exec(compile(cell.source,'analysis.ipynb','exec'),env)
        cell.execution_count=count;cell.outputs=[nbformat.v4.new_output('stream',name='stdout',text=buf.getvalue())]
finally:os.chdir(old)
nbformat.write(nb,ROOT/'analysis.ipynb')
print('Executed and saved',count,'analysis cells.')
