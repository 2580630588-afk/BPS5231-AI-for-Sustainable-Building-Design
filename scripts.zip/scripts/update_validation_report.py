"""Insert reproducible November results without regenerating the original manuscript."""
from pathlib import Path
import csv,json,re
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/final_validation'
def rows(name):
    with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    s=json.loads((OUT/'summary.json').read_text());worst=sorted([r for r in rows('stratified_errors.csv') if r['scheme']=='expanded_transfer'],key=lambda r:float(r['mae']),reverse=True)[:3]
    t='\n'.join(f"| {r['shape']} / {float(r['area']):g} | {r['contexts']} | {float(r['mae']):.2f} | {float(r['max_abs_error']):.2f} |" for r in worst)
    section=f'''### 4.5 Independent follow-up and subgroup errors

After the original results, 30 additional annual runs were specified on 18 November. Before running them, the model predictions, cases, a 50% mean-point DA300 screen and a rule comparator were frozen in data/final_validation/protocol.json. None of these geometry/area/orientation/WWR combinations occurs in the original 1,890 cases. These follow-up results are reported separately and never used for fitting or tuning.

Four daylight contexts combine rectangle 1.5:1 at 850 m² and 30°, and rectangle 3:1 at 1100 m² and 60°, each at WWR 0.2/0.4, with six options. Cooling MAE is {s['metrics']['independent_daylight']['mae']:.2f} kWh thermal/(m² year). Both the surrogate and the simple rule select the simulated minimum among daylight-feasible options in all four contexts. The rule selects the lowest SHGC, breaking ties by deeper overhang. Both methods receive the same simulated daylight feasibility. Their zero selection loss provides no evidence of a surrogate decision advantage over this rule. At WWR 0.2 both contexts select shaded SN70/35; at WWR 0.4 both select shaded SN40/23.

A fifth context tests the 600 m² wide-arm L at 0° and WWR 0.4. Its six cooling predictions have MAE {s['metrics']['independent_L600']['mae']:.2f} and maximum absolute error {s['metrics']['independent_L600']['max']:.2f}. This validates that specific combination, without validating all L shapes or other operating conditions. Across the five new contexts, the 75 within-context option-pair comparisons have difference MAE {s['pairwise_difference_mae']:.2f} and ordering agreement {s['pairwise_ordering_accuracy']*100:.1f}%. These dependent pairs are descriptive, not 75 independent observations.

The three highest-MAE shape/area subgroups of the original 384-case external test are:

| Shape / area m² | Contexts | MAE | Maximum error |
| :--- | ---: | ---: | ---: |
{t}

**Table 3.** Six paired strategies per context. Errors are kWh thermal/(m² year). All subgroups, empirical 95th-percentile errors and separate family-holdout/diagnostic results are provided in results/final_validation/stratified_errors.csv. Subgroup variation limits interpretation of pooled accuracy; these error summaries are not per-query confidence intervals.

The revised interface distinguishes exact simulation matches, evidence at other conditions of the same shape, and unsupported combinations. It lists the exact tested conditions and withholds comprehensive design recommendations when daylight is unavailable. The full study now contains 1,920 annual simulations: the original 1,890 plus 30 separately documented follow-up runs.

'''
    paper=ROOT/'deliverables/final_paper_editable.md';text=paper.read_text(encoding='utf-8-sig')
    text=re.sub(r'### 4\.5 Independent follow-up and subgroup errors\n.*?(?=## 5 Reproducibility)', '',text,flags=re.S)
    text=text.replace('## 5 Reproducibility',section+'## 5 Reproducibility').replace('*30 October 2026*','*18 November 2026*')
    abstract=' An independent 30-run follow-up confirms low prediction error but finds no selection advantage over a simple daylight-feasible SHGC rule.'
    if abstract.strip() not in text:text=text.replace('**Keywords:**',abstract.strip()+'\n\n**Keywords:**',1)
    conclusion=' The independent follow-up supports bounded prediction accuracy, while equal performance of the simple rule limits claims of AI-assisted selection benefit.'
    if conclusion.strip() not in text:text=text.replace('\n## References','\n'+conclusion.strip()+'\n\n## References')
    text=text.replace('A reproducible EnergyPlus 24.2 experiment comprises 1,890 annual simulations','The main EnergyPlus 24.2 experiment comprises 1,890 annual simulations')
    text=text.replace('**Table 1.** Final experiment, 1,890 simulations.','**Table 1.** Original experiment, 1,890 simulations; 30 follow-up runs are reported separately in Section 4.5.')
    text=text.replace('Daylight is available for two orientations and three WWRs only.','This original application covers two orientations and three WWRs; the independent follow-up uses four further contexts (Section 4.5).')
    text=text.replace('All 1,890 simulations have 8,760 hours and no severe errors.','All 1,920 simulations, including the 30 follow-up runs, have 8,760 hours and no severe errors.')
    paper.write_text(text,encoding='utf-8')
    report=f'''# 11月18日期末增补验证

原研究1890次模拟保持独立，新增30次，合计1920次。新增条件与原矩阵没有完全重复组合，预测和规则在运行前固定，未用于训练或调参。

## 新结果

- 四组独立矩形采光案例（24次模拟）：冷负荷MAE {s['metrics']['independent_daylight']['mae']:.3f} kWh热/(m²·年)。
- 600m²宽翼L形、0°、40%窗墙比（6次模拟）：MAE {s['metrics']['independent_L600']['mae']:.3f}，最大误差 {s['metrics']['independent_L600']['max']:.3f}。
- 模型与简单规则在四组采光案例中全部选对。规则为：在模拟采光合格方案中选最低SHGC，同SHGC选更深挑檐。这不证明AI改善选型，价值仍主要在快速估计冷负荷和干预幅度。
- 75组方案两两比较的差值MAE {s['pairwise_difference_mae']:.3f}，排序一致率 {s['pairwise_ordering_accuracy']*100:.1f}%。这些来自五个场景的相关配对，不能当作75个独立样本。

## 答辩应修改的表述

“研究共完成1920次年度模拟，其中30次为原结果之后固定方案的独立增补验证。模型对这些条件预测准确，但简单规则同样选对了方案，所以研究没有证明AI比规则更擅长选型。应用价值在于有明确范围的快速定量比较。”

当前采光仍限于矩形示例，新增L形仅验证冷负荷。形状或面积匹配不等于朝向、窗墙比和运行条件也已验证。原论文第4.3节的案例仍是训练内演示，第4.5节才是新条件验证。

## 可复现操作

原分析：python scripts/analyze.py

增补结果分析：python scripts/final_validation.py analyze

重跑增补模拟：python scripts/final_validation.py run --energyplus "完整EnergyPlus24.2路径"

增补矩阵、冻结预测和协议在data/final_validation；结果、误差明细和决策对比在results/final_validation。不要删除冻结预测后重新生成来替代原验证。

应用启动：launch_interface.bat；新增预设可选择600m²宽翼L形、850m²矩形和1100m²矩形。查看已测试条件可核实每个组合。
'''
    (ROOT/'deliverables/期末增补验证说明.md').write_text(report,encoding='utf-8')
    print('Updated paper and Chinese follow-up report')
if __name__=='__main__':main()
