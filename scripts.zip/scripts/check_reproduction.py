"""Verify archive hashes and rerun analysis in a fresh extracted project copy."""
from pathlib import Path
import csv,hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
def main():
    dest=ROOT.parents[1]/'work'/('final_reproduction_'+str(time.time_ns()))
    with zipfile.ZipFile(ROOT.parent/'BPS5231_Window_Transfer_Final.zip') as z:z.extractall(dest)
    copy=dest/ROOT.name
    manifest=json.loads((copy/'package_manifest.json').read_text(encoding='utf-8'))
    for rel,info in manifest['files'].items():
        p=copy/rel
        assert p.stat().st_size==info['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256'],rel
    env=os.environ.copy();env.pop('PYTHONPATH',None);env['PYTHONNOUSERSITE']='1';env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
    for name in ['build_notebook.py','figures.py','verify.py']:
        with (dest/(name+'.log')).open('w',encoding='utf-8') as log:
            subprocess.run([sys.executable,str(copy/'scripts'/name)],cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    def rows(path):
        with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
    original=rows(ROOT/'results/pooled_metrics.csv');reproduced=rows(copy/'results/pooled_metrics.csv')
    assert len(original)==len(reproduced)
    maximum=0
    for a,b in zip(original,reproduced):
        assert a.keys()==b.keys()
        for key in a:
            try:delta=abs(float(a[key])-float(b[key]))
            except ValueError:assert a[key]==b[key];continue
            maximum=max(maximum,delta);assert delta<1e-9,(key,a[key],b[key])
    subprocess.run([sys.executable,'-m','pip','check'],env=env,check=True)
    freeze=subprocess.check_output([sys.executable,'-m','pip','freeze'],env=env,text=True)
    (ROOT/'requirements-validated-lock.txt').write_text(freeze,encoding='utf-8')
    report={'passed':True,'checked_files':len(manifest['files']),'metric_rows':len(original),'maximum_absolute_metric_difference':maximum,'rerun_scripts':['build_notebook.py (analyze, verify, final_validation)','figures.py','verify.py'],'scope':'Fresh extracted project copy and newly created virtual environment installed from requirements.txt; PYTHONPATH removed, user site disabled. Same Windows machine, not a fresh OS or rerun of all original simulations.','python':sys.executable,'copy':str(copy)}
    (ROOT/'results/reproducibility_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
