"""Build a portable archive, including cached results and a SHA256 manifest."""
from pathlib import Path
import hashlib,json,os,zipfile
ROOT=Path(__file__).resolve().parents[1]
def main():
    files=[]
    for base,dirs,names in os.walk(ROOT,followlinks=False):
        dirs[:]=[d for d in dirs if d not in {'node_modules','__pycache__','.venv','venv','build','.git','.ipynb_checkpoints'}]
        for name in names:
            if name.startswith('~$'):continue
            p=Path(base)/name;r=p.relative_to(ROOT)
            if name in {'package_manifest.json','Guardian_Coated_Glass_2025.pdf'} or p.suffix in {'.pyc','.sql'}:continue
            if r.parts[:2]==('results','runs') and name not in {'record.json','eplusout.err'}:continue
            files.append(p)
    files.sort()
    manifest={'files':{p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
    mp=ROOT/'package_manifest.json';mp.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    target=ROOT.parent/'BPS5231_Window_Transfer_Final.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files+[mp]:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    print(json.dumps({'archive':str(target),'files':len(files)+1,'bytes':target.stat().st_size}))
if __name__=='__main__':main()
