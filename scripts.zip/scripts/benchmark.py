"""Sequential EnergyPlus timing and paired-context diagnostics; no model tuning."""
from pathlib import Path
import sys,json,time,subprocess,statistics,shutil,argparse,pickle
import numpy as np
from experiment import ROOT,RES,RAW,IDF,read_csv,save_csv
from analyze import features

def main(exe):
 rows=read_csv(RES/'simulation_results.csv');art=pickle.load((RES/'surrogate.pkl').open('rb'));tmp=ROOT/'build/benchmark';tmp.mkdir(parents=True,exist_ok=True);timings=[]
 for shape in ['rect2','L','circle24']:
  r=next(r for r in rows if r['shape']==shape and float(r['area'])==900 and float(r['orientation'])==0 and float(r['wwr'])==.4 and r['product']=='SN75' and float(r['shade'])==0 and r['group'].startswith('train'))
  for rep in range(3):
   folder=tmp/f'{shape}_{rep}';t=time.perf_counter();p=subprocess.run([exe,'-w',str(RAW/'singapore_iwec.epw'),'-d',str(folder),str(IDF/(r['case_id']+'.idf'))],capture_output=True,text=True,timeout=300);dt=time.perf_counter()-t
   assert p.returncode==0;timings.append(dict(shape=shape,repeat=rep,seconds=dt))
 sim=statistics.median(r['seconds'] for r in timings);X=np.array([features(r) for r in rows if r['group'].startswith('test')]);m=art['model'];m.predict(X[:1]);t=time.perf_counter()
 for _ in range(1000):m.predict(X[:1])
 pred=(time.perf_counter()-t)/1000
 pr=read_csv(RES/'predictions.csv');chosen=art['selected'];a={r['case_id']:r for r in pr if r['scheme']=='expanded_transfer' and r['model']==chosen};b={r['case_id']:r for r in pr if r['scheme']=='expanded_transfer' and r['model']=='interpolation'};contexts={}
 for k,r in a.items():contexts.setdefault(r['context'],[]).append(abs(float(r['predicted'])-float(r['actual']))-abs(float(b[k]['predicted'])-float(b[k]['actual'])))
 vals=np.array([np.mean(v) for v in contexts.values()]);rng=np.random.default_rng(2026);boot=np.array([np.mean(rng.choice(vals,len(vals),replace=True)) for _ in range(2000)])
 domain=[]
 for r,x in zip([r for r in rows if r['group'].startswith('test')],X):
  d=float(art['nearest'].kneighbors(art['scaler'].transform(x[None,:12]))[0][0,0]);err=abs(float(a[r['case_id']]['predicted'])-float(a[r['case_id']]['actual']));domain.append(dict(case_id=r['case_id'],distance=d,flag=int(d>art['distance_threshold']),abs_error=err))
 z=read_csv(RES/'zoning_audit.csv');c=read_csv(RES/'circle_convergence.csv');sens=read_csv(RES/'sensitivity.csv');dl=read_csv(RES/'design_application.csv')
 result=dict(sequential_simulation_median_seconds=sim,single_prediction_seconds=pred,query_speed_ratio=sim/pred,conservative_training_cost_seconds=1008*sim,approx_break_even_queries=1008*sim/(sim-pred),timing_note='Median of 9 sequential runs across rectangle, L and circle. Training estimate assumes this median for every training case; workstation-dependent. Excludes validation data, UI and engineering effort.',bootstrap_mae_difference_vs_interpolation=float(np.mean(vals)),bootstrap_context_95pct_interval=list(np.quantile(boot,[.025,.975])),bootstrap_note='Resampled 64 paired simulated contexts, not real-building population uncertainty.',domain_flagged=sum(r['flag'] for r in domain),domain_total=len(domain),domain_warning_note='Geometric novelty heuristic, not calibrated error probability.',zoning_max_abs_pct=max(abs(float(r['difference_pct'])) for r in z),zoning_max_reduction_difference_pp=max(abs(float(r['reduction_difference_pp'])) for r in z),circle48_max_abs_pct=max(abs(float(r['relative_to_24_pct'])) for r in c if r['sides']=='48'),sensitivity_max_abs_reduction_change_pp=max(abs(float(r['reduction_change_pp'])) for r in sens),daylight_min=min(float(r['da300_mean_pct']) for r in dl),daylight_max=max(float(r['da300_mean_pct']) for r in dl))
 (RES/'additional_analysis.json').write_text(json.dumps(result,indent=2));save_csv(RES/'sequential_timing.csv',timings);save_csv(RES/'domain_checks.csv',domain);print(json.dumps(result,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--energyplus',required=True);main(ap.parse_args().energyplus)
