"""Separate November validation: freeze predictions before new simulations; never train.
python scripts/final_validation.py prepare
python scripts/final_validation.py run --energyplus PATH
python scripts/final_validation.py analyze
"""
from pathlib import Path
import argparse,json,pickle,hashlib,concurrent.futures,itertools
import numpy as np
import experiment as e
from analyze import features
ROOT=e.ROOT; OUT=ROOT/'results/final_validation'; DATA=ROOT/'data/final_validation'
OUT.mkdir(exist_ok=True);DATA.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cases():
    rr=[]
    for shape,A,o in [('rect1.5',850,30),('rect3',1100,60)]:
        for w in [.2,.4]:
            for product in e.PRODUCTS:
                for shade in [0,.6]:rr.append(e.make_case(shape,A,o,w,product,shade,'independent_daylight',daylight=1))
    for product in e.PRODUCTS:
        for shade in [0,.6]:rr.append(e.make_case('Lwide',600,0,.4,product,shade,'independent_L600'))
    return rr
def key(r):return (r['shape'],float(r['area']),float(r['orientation']),float(r['wwr']))
def prepare():
    rr=cases();old=e.read_csv(ROOT/'data/design_matrix.csv')
    assert not {key(r) for r in rr}&{key(r) for r in old},'New conditions must be absent from all original cases'
    protocol=DATA/'protocol.json'
    if protocol.exists():
        assert json.loads(protocol.read_text())['cases']==rr,'Do not overwrite frozen validation design'
        print('Using existing frozen protocol');return
    with (ROOT/'results/surrogate.pkl').open('rb') as f:model=pickle.load(f)['model']
    pp=model.predict(np.array([features(r) for r in rr]))
    (DATA/'idf').mkdir(exist_ok=True)
    for r in rr:e.write_idf(DATA/'idf'/(r['case_id']+'.idf'),e.build(r)[0])
    e.save_csv(DATA/'design_matrix.csv',rr)
    e.save_csv(DATA/'frozen_predictions.csv',[dict(case_id=r['case_id'],predicted=float(p)) for r,p in zip(rr,pp)])
    protocol.write_text(json.dumps(dict(stage='Follow-up validation, chosen after original results; fixed before these runs',cases=rr,daylight_threshold=50,rule='Among simulated daylight-feasible options, lowest SHGC; ties prefer deeper overhang, then product name.',model_sha256=digest(ROOT/'results/surrogate.pkl'),predictions_sha256=digest(DATA/'frozen_predictions.csv'),no_training_or_tuning=True),indent=2))
    print('Frozen 30 new cases and predictions before simulation',flush=True)
def run(exe):
    assert (DATA/'protocol.json').exists(),'Run prepare first'
    e.RES=OUT;e.IDF=DATA/'idf'
    import subprocess
    version=subprocess.check_output([exe,'--version'],text=True).strip();assert '24.2' in version
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs=[pool.submit(e.runone,r,exe) for r in cases()]
        for job in concurrent.futures.as_completed(jobs):
            results.append(job.result());print('New simulation',len(results),'/30',flush=True)
    e.save_csv(OUT/'simulation_results.csv',sorted(results,key=lambda r:r['case_id']))
    (OUT/'engine.json').write_text(json.dumps(dict(version=version,sha256=digest(Path(exe))),indent=2))
def analyze():
    protocol=json.loads((DATA/'protocol.json').read_text())
    assert digest(DATA/'frozen_predictions.csv')==protocol['predictions_sha256']
    rows=e.read_csv(OUT/'simulation_results.csv');assert len(rows)==30
    pred={r['case_id']:float(r['predicted']) for r in e.read_csv(DATA/'frozen_predictions.csv')}
    for r in rows:
        assert int(r['hours'])==8760
        err=(OUT/'runs'/r['case_id']/'eplusout.err').read_text(errors='replace')
        assert '** Severe **' not in err and '**  Fatal  **' not in err
        r['actual']=float(r['cooling_kwh_th_m2']);r['predicted']=pred[r['case_id']]
        r['absolute_error']=abs(r['predicted']-r['actual'])
    choices=[];pairs=[]
    for ctx in sorted({r['context'] for r in rows}):
        rr=[r for r in rows if r['context']==ctx];assert len(rr)==6
        for a,b in itertools.combinations(rr,2):
            actual=a['actual']-b['actual'];estimated=a['predicted']-b['predicted']
            pairs.append(dict(context=ctx,case_a=a['case_id'],case_b=b['case_id'],actual_difference=actual,predicted_difference=estimated,absolute_error=abs(actual-estimated),ordering_correct=(actual*estimated>=0)))
        if rr[0]['group']!='independent_daylight':continue
        feasible=[r for r in rr if float(r['da300_mean_pct'])>=protocol['daylight_threshold']]
        best=min(feasible,key=lambda r:r['actual']) if feasible else None
        chosen=min(feasible,key=lambda r:r['predicted']) if feasible else None
        rule=min(feasible,key=lambda r:(float(r['shgc']),-float(r['shade']),r['product'])) if feasible else None
        option=lambda r:r['product']+'/'+str(r['shade']) if r else 'none'
        choices.append(dict(context=ctx,feasible=len(feasible),simulation_best=option(best),model_choice=option(chosen),rule_choice=option(rule),model_regret=chosen['actual']-best['actual'] if best else '',rule_regret=rule['actual']-best['actual'] if best else '',note='Both methods receive the same simulated daylight feasibility; no learned daylight prediction.'))
    e.save_csv(OUT/'predictions.csv',rows);e.save_csv(OUT/'decisions.csv',choices);e.save_csv(OUT/'pairwise_errors.csv',pairs)
    # Stratify existing independent predictions without merging different test roles.
    source={r['case_id']:r for r in e.read_csv(ROOT/'results/simulation_results.csv')};groups={}
    for r in e.read_csv(ROOT/'results/predictions.csv'):
        if r['model']!='ridge' or r['scheme'] not in ['expanded_transfer','whole_family_holdout','diagnostic_transfer']:continue
        s=source[r['case_id']];k=(r['scheme'],s['group'],s['shape'],s['area'])
        groups.setdefault(k,[]).append((r,s))
    strata=[]
    for (scheme,group,shape,area),rs in sorted(groups.items()):
        errors=np.array([abs(float(r['actual'])-float(r['predicted'])) for r,s in rs]);contexts={r['context'] for r,s in rs}
        strata.append(dict(scheme=scheme,group=group,shape=shape,area=area,n=len(rs),contexts=len(contexts),mae=float(errors.mean()),p95_abs_error=float(np.quantile(errors,.95)),max_abs_error=float(errors.max())))
    e.save_csv(OUT/'stratified_errors.csv',strata)
    metrics={}
    for group in sorted({r['group'] for r in rows}):
        ss=[r for r in rows if r['group']==group];err=np.array([r['absolute_error'] for r in ss])
        metrics[group]=dict(n=len(ss),mae=float(err.mean()),p95=float(np.quantile(err,.95)),max=float(err.max()))
    summary=dict(cases=30,severe_errors=0,training_unchanged=True,metrics=metrics,daylight_contexts=len(choices),model_total_regret=sum(float(r['model_regret']) for r in choices if r['model_regret']!=''),rule_total_regret=sum(float(r['rule_regret']) for r in choices if r['rule_regret']!=''),pairwise_difference_mae=float(np.mean([r['absolute_error'] for r in pairs])),pairwise_ordering_accuracy=float(np.mean([r['ordering_correct'] for r in pairs])),limitations='Four rectangle daylight contexts; one L600 thermal context; follow-up design after earlier results; simulated daylight provided to both selectors; no empirical validation.')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','run','analyze']);p.add_argument('--energyplus');a=p.parse_args()
    if a.command=='run':run(a.energyplus)
    elif a.command=='prepare':prepare()
    else:analyze()
