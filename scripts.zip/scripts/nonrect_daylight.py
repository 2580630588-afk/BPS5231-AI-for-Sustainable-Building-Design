"""Frozen nonrectangular daylight follow-up; never fit or tune the surrogate.

python scripts/nonrect_daylight.py prepare
python scripts/nonrect_daylight.py run --energyplus PATH
python scripts/nonrect_daylight.py analyze

Primary 4 m clipped-cell sampling and a prespecified 2 m sampling audit use
the same ten physical contexts. The audit is not additional independent data.
"""
from pathlib import Path
import argparse, concurrent.futures, datetime, hashlib, itertools, json, math
import pickle, re, sqlite3, subprocess, time
import numpy as np
import experiment as e
from analyze import features

ROOT=e.ROOT
DATA=ROOT/'data/nonrect_daylight'
OUT=ROOT/'results/nonrect_daylight'
SHAPES=['Lwide','triangle','pentagon','hexagon','circle24']
LABELS={'Lwide':'Wide-arm L','triangle':'Triangle','pentagon':'Pentagon','hexagon':'Hexagon','circle24':'Circle (24-gon)'}

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def clip(poly,axis,bound,greater):
    """Sutherland-Hodgman half-plane clipping of a convex triangle fragment."""
    if not poly:return []
    result=[]
    prev=poly[-1];pin=(prev[axis]>=bound if greater else prev[axis]<=bound)
    for cur in poly:
        cin=(cur[axis]>=bound if greater else cur[axis]<=bound)
        if cin!=pin:
            t=(bound-prev[axis])/(cur[axis]-prev[axis])
            result.append(tuple(prev[k]+t*(cur[k]-prev[k]) for k in [0,1]))
        if cin:result.append(cur)
        prev,pin=cur,cin
    return result

def centroid(poly):
    a=e.signed(poly)
    return tuple(sum((p[k]+q[k])*(p[0]*q[1]-q[0]*p[1]) for p,q in zip(poly,poly[1:]+poly[:1]))/(6*a) for k in [0,1])

def clearance(point,vertices):
    return min(abs((b[0]-a[0])*(point[1]-a[1])-(b[1]-a[1])*(point[0]-a[0]))/math.dist(a,b) for a,b in zip(vertices,vertices[1:]+vertices[:1]))

def safe_point(point,vertices):
    # EnergyPlus requires >=0.15 m from a window plane. Apply the same
    # conservative 0.20 m rule to all wall planes for every shape/option/grid.
    if clearance(point,vertices)>=.20:return point
    for step in range(1,81):
        radius=step*.025
        for k in range(144):
            theta=2*math.pi*k/144
            p=(point[0]+radius*math.cos(theta),point[1]+radius*math.sin(theta))
            if e.inside(p,vertices) and clearance(p,vertices)>=.20:return p
    raise ValueError('No safe interior sample found within 2 m')

def sensors(shape,area,spacing):
    """One interior point per clipped square cell, weighted by its actual area.

    Triangulation computes clipped areas without adding a geometry dependency.
    For a concave cell whose combined centroid lies outside, use the centroid
    of its largest convex fragment. Both grids cover the entire floor area.
    """
    v=e.polygon(shape,area);tris=e.triangles(v);points=[]
    for i in range(math.ceil(max(x for x,y in v)/spacing)):
        for j in range(math.ceil(max(y for x,y in v)/spacing)):
            fragments=[]
            for tri in tris:
                p=tri
                for axis,b,g in [(0,i*spacing,True),(0,(i+1)*spacing,False),(1,j*spacing,True),(1,(j+1)*spacing,False)]:
                    p=clip(p,axis,b,g)
                if len(p)>=3 and e.signed(p)>1e-9:fragments.append((e.signed(p),centroid(p)))
            if not fragments:continue
            weight=sum(a for a,c in fragments)
            c=tuple(sum(a*p[k] for a,p in fragments)/weight for k in [0,1])
            fallback=not e.inside(c,v)
            if fallback:c=max(fragments,key=lambda f:f[0])[1]
            original=c;c=safe_point(c,v)
            assert e.inside(c,v)
            points.append(dict(name=f'Sensor{len(points)}',x=c[0],y=c[1],z=.8,represented_area=weight,weight=weight/area,cell_i=i,cell_j=j,centroid_fallback=fallback,safety_shift_m=math.dist(original,c),window_plane_clearance_m=clearance(c,v)))
    assert abs(sum(p['represented_area'] for p in points)-area)<1e-6
    assert abs(sum(p['weight'] for p in points)-1)<1e-9
    assert len({(round(p['x'],8),round(p['y'],8)) for p in points})==len(points)
    return points

def cases():
    rows=[]
    for spacing in [4,2]:
        for shape in SHAPES:
            for w in [.2,.4]:
                for product in e.PRODUCTS:
                    for shade in [0,.6]:
                        r=e.make_case(shape,850,30,w,product,shade,'nonrect_daylight' if spacing==4 else 'nonrect_grid_audit',daylight=1)
                        r.update(grid_spacing=spacing,daylight_method='area_weighted_clipped_grid',physical_context=r['context'])
                        r['context']+=f'_grid{spacing}';r['case_id']+=f'_grid{spacing}'
                        rows.append(r)
    return rows

def prepare():
    DATA.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True);(DATA/'idf').mkdir(exist_ok=True)
    rows=cases();protocol=DATA/'protocol.json'
    if protocol.exists():
        assert json.loads(protocol.read_text())['cases']==rows
        print('Using existing frozen nonrectangular protocol');return
    old=e.read_csv(ROOT/'data/design_matrix.csv')+e.read_csv(ROOT/'data/final_validation/design_matrix.csv')
    key=lambda r:(r['shape'],float(r['area']),float(r['orientation']),float(r['wwr']))
    assert not {key(r) for r in rows}&{key(r) for r in old}
    with (ROOT/'results/surrogate.pkl').open('rb') as f:model=pickle.load(f)['model']
    predictions=model.predict(np.array([features(r) for r in rows]))
    sensorrows=[];qa=[]
    for shape in SHAPES:
        for spacing in [4,2]:
            pp=sensors(shape,850,spacing)
            sensorrows.extend(dict(shape=shape,area=850,grid_spacing=spacing,**p) for p in pp)
            qa.append(dict(shape=shape,spacing=spacing,points=len(pp),area=sum(p['represented_area'] for p in pp),all_inside=True))
    idfhashes={}
    for r in rows:
        pp=[p for p in sensorrows if p['shape']==r['shape'] and p['grid_spacing']==r['grid_spacing']]
        obs,_=e.build(r)
        obs=[o for o in obs if not o[0].startswith('Daylighting:') and not (o[0]=='Output:Variable' and o[2].startswith('Daylighting Reference Point'))]
        ctrl=['Daylighting:Controls','Daylight','Office','SplitFlux','','Continuous','.3','.2','1','1','','0','22','']
        for p in pp:
            obs.append(['Daylighting:ReferencePoint',p['name'],'Office',str(p['x']),str(p['y']),'.8'])
            ctrl += [p['name'],'0','300']
        obs.append(ctrl)
        obs.extend([['Output:Variable','*',f'Daylighting Reference Point {k+1} Illuminance','Hourly'] for k in range(len(pp))])
        target=DATA/'idf'/(r['case_id']+'.idf');e.write_idf(target,obs);idfhashes[r['case_id']]=digest(target)
    e.save_csv(DATA/'sensor_points.csv',sensorrows);e.save_csv(DATA/'design_matrix.csv',rows)
    e.save_csv(DATA/'frozen_predictions.csv',[dict(case_id=r['case_id'],predicted=float(p)) for r,p in zip(rows,predictions)])
    protocol.write_text(json.dumps(dict(stage='2026-11-19 post-hoc extension; sampling revision 2 fixed before corrected simulations',revision=2,revision_reason='Initial centroid-only attempt triggered EnergyPlus <0.15 m window-plane errors. All grids now enforce 0.20 m clearance by a deterministic nearest radial search (0.025 m steps, 2.5 degree directions). Cases, predictions, thresholds and selection rules are unchanged. Initial-attempt logs and protocol are retained in revisions/. No performance-based sample selection.',cases=rows,independent_physical_contexts=10,primary_runs=60,grid_audit_runs=60,primary_spacing_m=4,audit_spacing_m=2,area=850,orientation=30,wwr=[.2,.4],threshold=50,illuminance_lux=300,reference_height_m=.8,occupied_hour_endings=[10,18],calendar_year=2006,aggregation='Sum of point DA300 times clipped cell area / floor area; not sDA or compliance.',decision_rule='Among simulated daylight-feasible options choose minimum SHGC, then deeper overhang, then product name.',sampling_audit='Compare absolute DA300 percentage-point changes, feasibility changes and selected-option changes. Grid refinement is not physical validation.',lighting_control_fraction=0,no_training_or_tuning=True,model_sha256=digest(ROOT/'results/surrogate.pkl'),predictions_sha256=digest(DATA/'frozen_predictions.csv'),sensors_sha256=digest(DATA/'sensor_points.csv'),idf_sha256=idfhashes,geometry_checks=qa,method_source='https://bigladdersoftware.com/epx/docs/24-2/input-output-reference/group-daylighting.html',limitations='SplitFlux approximation, empty open-plan floor, no glare or furniture, one area/orientation per shape; L-shape reflected component is not independently ray-traced.'),indent=2),encoding='utf-8')
    print('Frozen 60 primary + 60 grid-audit cases and predictions.',flush=True)
    print(json.dumps(qa,indent=2))

def runone(r,exe,protocol,points):
    folder=OUT/'runs'/r['case_id'];folder.mkdir(parents=True,exist_ok=True)
    model=DATA/'idf'/(r['case_id']+'.idf');weather=e.RAW/'singapore_iwec.epw'
    assert digest(model)==protocol['idf_sha256'][r['case_id']]
    sig=hashlib.sha256(model.read_bytes()+weather.read_bytes()+Path(exe).read_bytes()+json.dumps(points,sort_keys=True).encode()).hexdigest()
    cache=folder/'record.json'
    if cache.exists():
        prev=json.loads(cache.read_text())
        if prev.get('input_hash')==sig:return prev
    start=time.perf_counter()
    p=subprocess.run([exe,'-w',str(weather),'-d',str(folder),str(model)],capture_output=True,text=True,timeout=1200)
    err=(folder/'eplusout.err').read_text(errors='replace') if (folder/'eplusout.err').exists() else p.stderr
    if p.returncode or '** Severe **' in err or '**  Fatal  **' in err:raise RuntimeError(r['case_id']+'\n'+err[-6000:])
    db=sqlite3.connect(folder/'eplusout.sql')
    hrs=db.execute('''SELECT r.TimeIndex,SUM(r.Value),COUNT(*) FROM ReportData r JOIN ReportDataDictionary d USING(ReportDataDictionaryIndex) JOIN Time t USING(TimeIndex) JOIN EnvironmentPeriods e USING(EnvironmentPeriodIndex) WHERE d.Name=? AND d.ReportingFrequency='Hourly' AND COALESCE(t.WarmupFlag,0)=0 AND e.EnvironmentType=3 GROUP BY r.TimeIndex ORDER BY r.TimeIndex''',(e.Q,)).fetchall()
    assert len(hrs)==8760 and all(n==1 for _,_,n in hrs)
    groups={};all_hours={}
    query='''SELECT d.Name,t.Month,t.Day,t.Hour,r.Value FROM ReportData r JOIN ReportDataDictionary d USING(ReportDataDictionaryIndex) JOIN Time t USING(TimeIndex) JOIN EnvironmentPeriods e USING(EnvironmentPeriodIndex) WHERE d.Name LIKE 'Daylighting Reference Point % Illuminance' AND d.ReportingFrequency='Hourly' AND COALESCE(t.WarmupFlag,0)=0 AND e.EnvironmentType=3'''
    for name,month,day,hour,value in db.execute(query):
        idx=int(re.search(r'Point (\d+) Illuminance',name).group(1))-1
        assert math.isfinite(value) and value>=-1e-6
        all_hours[idx]=all_hours.get(idx,0)+1
        if datetime.date(2006,month,day).weekday()<5 and 10<=hour<=18:groups.setdefault(idx,[]).append(value)
    db.close()
    assert set(groups)==set(range(len(points)))
    assert all(n==8760 for n in all_hours.values())
    assert all(len(v)==2340 for v in groups.values())
    vals=[100*sum(v>=300 for v in groups[i])/len(groups[i]) for i in range(len(points))]
    sensor_results=[dict(**p,da300_pct=v,occupied_hours=len(groups[i])) for i,(p,v) in enumerate(zip(points,vals))]
    e.save_csv(folder/'sensor_results.csv',sensor_results)
    annual=sum(v for _,v,_ in hrs)/3.6e6
    rec=dict(**r,**e.geom(r),cooling_kwh_th=annual,cooling_kwh_th_m2=annual/r['area'],hours=8760,occupied_hours=2340,da300_mean_pct=sum(float(p['weight'])*v for p,v in zip(points,vals)),da300_min_pct=min(vals),daylight_points=len(points),warnings=err.count('** Warning **'),runtime_seconds=time.perf_counter()-start,input_hash=sig)
    cache.write_text(json.dumps(rec,indent=2))
    # Only known generated simulation files in this verified case folder.
    for f in folder.iterdir():
        if f.is_file() and f.name not in ['record.json','eplusout.err','sensor_results.csv']:f.unlink()
    return rec

def run(exe,workers,limit):
    protocol=json.loads((DATA/'protocol.json').read_text())
    assert digest(DATA/'sensor_points.csv')==protocol['sensors_sha256']
    version=subprocess.check_output([exe,'--version'],text=True).strip();assert '24.2' in version
    points=e.read_csv(DATA/'sensor_points.csv');rows=cases();results=[]
    if limit:rows=rows[:limit]
    start=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(runone,r,exe,protocol,[p for p in points if p['shape']==r['shape'] and float(p['grid_spacing'])==r['grid_spacing']]) for r in rows]
        for job in concurrent.futures.as_completed(futures):
            results.append(job.result());print(f'Completed {len(results)}/{len(rows)}; elapsed {time.perf_counter()-start:.1f}s',flush=True)
    records=[json.loads(p.read_text()) for p in (OUT/'runs').glob('*/record.json')]
    e.save_csv(OUT/'simulation_results.csv',sorted(records,key=lambda r:r['case_id']))
    (OUT/'engine.json').write_text(json.dumps(dict(version=version,sha256=digest(Path(exe)),wall_seconds=time.perf_counter()-start),indent=2))

def decide(rr,threshold):
    opt=lambda r:r['product']+'/'+str(float(r['shade'])) if r else 'none'
    feasible=[r for r in rr if r['da']>=threshold]
    raw=min(rr,key=lambda r:r['actual'])
    best=min(feasible,key=lambda r:r['actual']) if feasible else None
    model=min(feasible,key=lambda r:r['predicted']) if feasible else None
    rule=min(feasible,key=lambda r:(float(r['shgc']),-float(r['shade']),r['product'])) if feasible else None
    return dict(shape=rr[0]['shape'],wwr=float(rr[0]['wwr']),grid_spacing=float(rr[0]['grid_spacing']),context=rr[0]['context'],feasible=len(feasible),unconstrained=opt(raw),simulation_best=opt(best),model_choice=opt(model),rule_choice=opt(rule),model_regret=model['actual']-best['actual'] if best else None,rule_regret=rule['actual']-best['actual'] if best else None,cooling_cost=best['actual']-raw['actual'] if best else None,changed_by_daylight=opt(best)!=opt(raw),selected_da=best['da'] if best else None,selected_cooling=best['actual'] if best else None)

def analyze():
    protocol=json.loads((DATA/'protocol.json').read_text())
    assert digest(DATA/'frozen_predictions.csv')==protocol['predictions_sha256']
    assert digest(DATA/'sensor_points.csv')==protocol['sensors_sha256']
    rows=e.read_csv(OUT/'simulation_results.csv');assert len(rows)==120
    assert {r['case_id'] for r in rows}=={r['case_id'] for r in cases()}
    predictions={r['case_id']:float(r['predicted']) for r in e.read_csv(DATA/'frozen_predictions.csv')}
    warnings={}
    for r in rows:
        r.update(actual=float(r['cooling_kwh_th_m2']),predicted=predictions[r['case_id']],da=float(r['da300_mean_pct']))
        assert int(r['hours'])==8760 and int(r['occupied_hours'])==2340 and 0<=r['da']<=100
        err=(OUT/'runs'/r['case_id']/'eplusout.err').read_text(errors='replace')
        assert '** Severe **' not in err and '**  Fatal  **' not in err
        assert digest(DATA/'idf'/(r['case_id']+'.idf'))==protocol['idf_sha256'][r['case_id']]
        points=e.read_csv(OUT/'runs'/r['case_id']/'sensor_results.csv')
        assert len(points)==int(r['daylight_points'])
        assert all(int(p['occupied_hours'])==2340 and 0<=float(p['da300_pct'])<=100 for p in points)
        assert abs(sum(float(p['represented_area']) for p in points)-float(r['area']))<1e-6
        assert abs(sum(float(p['weight'])*float(p['da300_pct']) for p in points)-r['da'])<1e-8
        for line in err.splitlines():
            if '** Warning **' in line:
                category=line.split('** Warning **',1)[1].strip().split('=')[0]
                warnings[category]=warnings.get(category,0)+1
    decisions=[decide([r for r in rows if r['context']==c],protocol['threshold']) for c in sorted({r['context'] for r in rows})]
    primary=[r for r in rows if float(r['grid_spacing'])==4]
    audits=[]
    for a in primary:
        b=next(r for r in rows if r['physical_context']==a['physical_context'] and r['product']==a['product'] and r['shade']==a['shade'] and float(r['grid_spacing'])==2)
        audits.append(dict(shape=a['shape'],wwr=a['wwr'],product=a['product'],shade=a['shade'],da_4m=a['da'],da_2m=b['da'],absolute_da_difference_pp=abs(a['da']-b['da']),feasibility_changed=(a['da']>=50)!=(b['da']>=50),cooling_difference=abs(a['actual']-b['actual'])))
    strata=[]
    for shape in SHAPES:
        rr=[r for r in primary if r['shape']==shape];aa=[a for a in audits if a['shape']==shape]
        dd=[d for d in decisions if d['shape']==shape and d['grid_spacing']==4]
        fine=[d for d in decisions if d['shape']==shape and d['grid_spacing']==2]
        errors=[abs(r['actual']-r['predicted']) for r in rr]
        strata.append(dict(shape=shape,cases=len(rr),mae=float(np.mean(errors)),max_error=max(errors),daylight_changed_choices=sum(d['changed_by_daylight'] for d in dd),model_correct=sum(d['model_choice']==d['simulation_best'] for d in dd if d['feasible']),rule_correct=sum(d['rule_choice']==d['simulation_best'] for d in dd if d['feasible']),max_grid_difference_pp=max(a['absolute_da_difference_pp'] for a in aa),mean_grid_difference_pp=float(np.mean([a['absolute_da_difference_pp'] for a in aa])),feasibility_flips=sum(a['feasibility_changed'] for a in aa),choice_grid_changes=sum(d['simulation_best']!=next(f['simulation_best'] for f in fine if f['wwr']==d['wwr']) for d in dd)))
    d4=[d for d in decisions if d['grid_spacing']==4]
    summary=dict(primary_cases=60,audit_cases=60,independent_contexts=10,total_project_simulations=2040,primary_mae=float(np.mean([abs(r['actual']-r['predicted']) for r in primary])),severe_errors=0,no_training_or_tuning=True,feasible_contexts=sum(d['feasible']>0 for d in d4),choices_changed_by_daylight=sum(d['changed_by_daylight'] for d in d4),model_correct=sum(d['model_choice']==d['simulation_best'] for d in d4 if d['feasible']),rule_correct=sum(d['rule_choice']==d['simulation_best'] for d in d4 if d['feasible']),model_total_regret=sum(d['model_regret'] or 0 for d in d4),rule_total_regret=sum(d['rule_regret'] or 0 for d in d4),max_grid_difference_pp=max(a['absolute_da_difference_pp'] for a in audits),mean_grid_difference_pp=float(np.mean([a['absolute_da_difference_pp'] for a in audits])),grid_feasibility_flips=sum(a['feasibility_changed'] for a in audits),grid_choice_changes=sum(s['choice_grid_changes'] for s in strata),max_cooling_grid_difference=max(a['cooling_difference'] for a in audits),strata=strata,warning_categories=warnings,limits=protocol['limitations'])
    e.save_csv(OUT/'predictions.csv',rows);e.save_csv(OUT/'decisions.csv',decisions);e.save_csv(OUT/'grid_comparison.csv',audits);e.save_csv(OUT/'shape_metrics.csv',strata)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
    figures(rows,decisions)
    report(summary,decisions)

def report(s,decisions):
    names={'Lwide':'宽翼L形','triangle':'等边三角形','pentagon':'正五边形','hexagon':'正六边形','circle24':'圆形（24边近似）'}
    lines=['# 非矩形采光独立验证',
      '## 试验范围与计算方法',
      '本轮为看到此前研究结果后制定的补充试验。模拟运行前固定了全部案例、冷却需求预测、筛选阈值和比较规则。新增数据不参与训练、调参或模型选择。',
      '宽翼L形、等边三角形、正五边形、正六边形与24边形近似圆形均采用850 m²、30°，窗墙比为20%和40%。每种条件比较三种玻璃×两种挑檐，共10个独立条件、60个主试验。另60次2 m网格模拟是测点敏感性复核，不应算作新增独立设计样本。项目累计2,040次年度模拟。',
      '主试验使用4 m方格裁剪至真实平面轮廓，每个裁剪单元布置一个0.8 m高测点，以单元实际面积作为权重。若凹单元的合并重心在建筑外，则采用该单元最大三角裁剪片的重心。保留所有单元，权重之和为1。复核网格为2 m。',
      '初始重心布点触发EnergyPlus距窗面小于0.15 m的计算限制，因此在正式修正版模拟前统一增加0.20 m安全距离。对不满足距离的点，采用0.025 m径向步长、2.5°方向间隔的确定性搜索移动至最近可用位置，保留原单元面积权重。原方案、报错和预测保存于revisions；没有按性能结果挑选案例或调整阈值。',
      '每个测点统计2006非闰年日历中工作日、小时结束时刻10:00—18:00，共2,340小时内照度≥300 lux的时间百分比；再按面积权重求平均。这个平均DA300不是达到标准的面积百分比，也不是sDA、眩光或法规合规评价。',
      '可行性定义为上述加权DA300≥50%。模型和简单规则共用模拟得到的可行性：模型在可行方案中选择预测冷却需求最低者；规则选择SHGC最低者，同值时优先较深挑檐，再按产品名称排序。实际最优使用同一可行集合中的模拟冷却需求。',
      '## 主要结果',
      f"60个主试验的冷却需求MAE为{s['primary_mae']:.3f} kWh热/(m²·年)。10个条件中，{s['choices_changed_by_daylight']}个因加入采光约束改变了纯冷却最优方案。模型命中实际可行最优{s['model_correct']}/{s['feasible_contexts']}；简单规则命中{s['rule_correct']}/{s['feasible_contexts']}。",
      '| 形态 | 窗墙比 | 可行方案数 | 纯冷却最优 | 加采光后最优 | 冷却代价 kWh热/(m²·年) |',
      '|---|---:|---:|---|---|---:|']
    for d in decisions:
        if d['grid_spacing']!=4:continue
        cost=f"{d['cooling_cost']:.3f}" if d['cooling_cost'] is not None else '无可行方案'
        lines.append(f"| {names[d['shape']]} | {d['wwr']:.0%} | {d['feasible']} | {d['unconstrained']} | {d['simulation_best']} | {cost} |")
    lines += ['## 网格复核与适用限制',f"4 m与2 m网格的平均绝对DA300差异为{s['mean_grid_difference_pp']:.3f}个百分点，最大{s['max_grid_difference_pp']:.3f}个百分点。60个配对方案中有{s['grid_feasibility_flips']}个改变可行性；10个条件中有{s['grid_choice_changes']}个改变实际最优选项。最大冷却需求差异为{s['max_cooling_grid_difference']:.6f} kWh热/(m²·年)。",
      '网格复核只能检查测点离散化敏感性，不能证明SplitFlux物理准确，也不能代表Radiance或实测验证。L形的直接遮挡由EnergyPlus模型处理，反射光仍采用简化计算；未建模家具、内部隔断与眩光。',
      '全部新增条件仅覆盖850 m²与30°，不能据此声明任意面积、朝向或非规则多边形均可使用综合选型。',
      '模型唯一优于规则的条件是等边三角形、20%窗墙比：模型选择SN70/35与0.6 m挑檐，规则选择SN40/23且无挑檐；前者的模拟冷却需求低0.208 kWh热/(m²·年)。这是一个范围明确的小优势，不能外推为模型普遍优于规则。预测还可用于量化冷却收益和采光约束的代价。',
      f"全部120次模拟完成8,760小时，无严重错误。警告分类保留于summary.json：{json.dumps(s['warning_categories'],ensure_ascii=False)}。不开启眩光计算与采光调光是本次设定，不代表相应性能已满足要求。",
      '## 可复现文件',
      '- `data/nonrect_daylight/protocol.json`：冻结的设计与哈希。\n- `data/nonrect_daylight/sensor_points.csv`：测点坐标、代表面积和权重。\n- `data/nonrect_daylight/frozen_predictions.csv`：运行模拟之前冻结的预测。\n- `results/nonrect_daylight/simulation_results.csv`：120次结果。\n- `results/nonrect_daylight/decisions.csv`：主试验及加密网格选型。\n- `results/nonrect_daylight/grid_comparison.csv`：60对网格对照。\n- `results/nonrect_daylight/runs/`：每次模拟的记录、警告和逐点DA300。',
      '从项目根目录运行：`python scripts/nonrect_daylight.py analyze`。重新模拟使用：`python scripts/nonrect_daylight.py run --energyplus "EnergyPlus 24.2的完整路径"`。原始研究与此前30次补充模拟保留在各自目录。',
      '方法依据：[EnergyPlus 24.2 Daylighting](https://bigladdersoftware.com/epx/docs/24-2/input-output-reference/group-daylighting.html)。']
    (ROOT/'deliverables/非矩形采光验证说明.md').write_text('\n\n'.join(lines),encoding='utf-8')

def figures(rows,decisions):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    target=OUT/'figures';target.mkdir(exist_ok=True)
    pp=e.read_csv(DATA/'sensor_points.csv')
    fig,axes=plt.subplots(1,5,figsize=(12,3.2),layout='constrained')
    for ax,shape in zip(axes,SHAPES):
        v=e.polygon(shape,850);v=v+[v[0]];ax.plot(*zip(*v),color='#163343')
        p4=[p for p in pp if p['shape']==shape and float(p['grid_spacing'])==4]
        ax.scatter([float(p['x']) for p in p4],[float(p['y']) for p in p4],s=[float(p['weight'])*1200 for p in p4],color='#087f8c')
        ax.set_title(f'{LABELS[shape]}\n{len(p4)} points',fontsize=10);ax.set_aspect('equal');ax.set_xlabel('Local x (m)');ax.tick_params(labelsize=8)
    axes[0].set_ylabel('Local y (m)');fig.savefig(target/'sampling_points.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(2,5,figsize=(12,5.2),layout='constrained')
    colors={'SN75':'#5d7384','SN7035':'#07818d','SN4023':'#bf681f'}
    for j,shape in enumerate(SHAPES):
        for i,w in enumerate([.2,.4]):
            ax=axes[i,j];rr=[r for r in rows if r['shape']==shape and float(r['wwr'])==w and float(r['grid_spacing'])==4]
            for r in rr:
                ax.scatter(r['da'],r['actual'],marker='s' if float(r['shade']) else 'o',color=colors[r['product']],s=34)
            ax.axvline(50,ls='--',color='#888',lw=1);ax.set_xlim(0,100);ax.set_title(f'{LABELS[shape]} | WWR {w:.0%}',fontsize=9);ax.tick_params(labelsize=8)
            if i==1:ax.set_xlabel('Area-weighted DA300 (%)',fontsize=8)
            if j==0:ax.set_ylabel('Cooling [kWh th/(m² yr)]',fontsize=8)
    from matplotlib.lines import Line2D
    handles=[Line2D([],[],marker='o',ls='',color=c,label=p) for p,c in colors.items()]+[Line2D([],[],marker='s',ls='',color='#222',label='0.6 m overhang')]
    fig.legend(handles=handles,loc='outside lower center',ncol=4,fontsize=9);fig.savefig(target/'daylight_cooling_tradeoff.png',dpi=180);plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','run','analyze']);p.add_argument('--energyplus');p.add_argument('--workers',type=int,default=4);p.add_argument('--limit',type=int);a=p.parse_args()
    if a.command=='prepare':prepare()
    elif a.command=='run':run(a.energyplus,a.workers,a.limit)
    else:analyze()
