from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree
import sys
p=Path(sys.argv[1]);tmp=p.with_suffix('.clean.pptx')
with ZipFile(p) as src, ZipFile(tmp,'w',ZIP_DEFLATED) as out:
 for item in src.infolist():
  n=item.filename
  if n.startswith(('ppt/notesSlides/','ppt/notesMasters/')):continue
  data=src.read(n)
  if n.endswith('.rels') or n=='[Content_Types].xml' or n=='ppt/presentation.xml':
   root=etree.fromstring(data)
   for el in list(root.iter()):
    if el is root:continue
    if (el.get('Type','').endswith(('/notesSlide','/notesMaster')) or el.get('PartName','').startswith(('/ppt/notesSlides/','/ppt/notesMasters/')) or etree.QName(el).localname=='notesMasterIdLst'):
     el.getparent().remove(el)
   data=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
  out.writestr(item,data)
tmp.replace(p)
with ZipFile(p) as z:assert not any(n.startswith(('ppt/notesSlides/','ppt/notesMasters/')) for n in z.namelist())
