"""Check a running local app: python scripts/check_interface.py --url http://127.0.0.1:8765"""
from pathlib import Path
import argparse,json,time,urllib.request,statistics
p=argparse.ArgumentParser();p.add_argument('--url',default='http://127.0.0.1:8765');a=p.parse_args()
checks=[]
queries=['shape=Lwide&area=600&orientation=0&wwr=0.4','shape=rect1.5&area=850&orientation=30&wwr=0.2','shape=triangle&area=850&orientation=30&wwr=0.2','shape=triangle&area=800&orientation=20&wwr=0.3']
def get(q):
    with urllib.request.urlopen(a.url+'/api/predict?'+q,timeout=15) as f:return json.load(f)
for q in queries:
    d=get(q);assert len(d['options'])==6 and d['coverage']
    checks.append(dict(query=q,exact=sum(x['simulation'] is not None for x in d['options']),daylight=sum(x['da300'] is not None for x in d['options']),fine_daylight=sum(x.get('da300_fine') is not None for x in d['options']),status=d['status']))
assert [(r['exact'],r['daylight'],r['fine_daylight']) for r in checks]==[(6,0,0),(6,6,0),(6,6,6),(0,0,0)]
times=[]
for i in range(20):
    t=time.perf_counter();get(queries[0]);times.append(time.perf_counter()-t)
report=dict(passed=True,checks=checks,six_option_http_median_ms=1000*statistics.median(times),requests=20,note='Warm local HTTP round-trip for one six-option panel, including inference and lookup, excluding browser rendering and cold startup.')
out=Path(__file__).resolve().parents[1]/'results/final_validation/interface_check.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('Passed, median ms:',report['six_option_http_median_ms'])
