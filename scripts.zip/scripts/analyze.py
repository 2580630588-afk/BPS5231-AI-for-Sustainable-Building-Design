"""Reproduce prediction, paired-effect, sensitivity and design-app analyses from CSV."""
from pathlib import Path
import json,math,time,pickle,statistics,sys
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor,NearestNeighbors
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from experiment import ROOT,RES,read_csv,save_csv,geom,PRODUCTS,polygon
FEATURES=['log_area','wall_floor','compactness','bbox_fill']+[f'exposure{k}' for k in range(8)]+['wwr','u','shgc','vt','shade']
SEED=2026
class StrategyMean:
 def fit(self,X,y):
  self.mu=float(np.mean(y));self.groups={tuple(k):float(np.mean(y[np.all(X[:,-4:]==k,axis=1)])) for k in np.unique(X[:,-4:],axis=0)};return self
 def predict(self,X):return np.array([self.groups.get(tuple(k),self.mu) for k in X[:,-4:]])
def features(r):
 g=geom(r);return [math.log(float(r['area'])),g['wall_floor'],g['compactness'],g['bbox_fill']]+[g[f'exposure{k}'] for k in range(8)]+[float(r[k]) for k in ['wwr','u','shgc','vt','shade']]
def builders():return {'strategy_mean':lambda:StrategyMean(),'interpolation':lambda:make_pipeline(StandardScaler(),KNeighborsRegressor(n_neighbors=5,weights='distance')),'ridge':lambda:make_pipeline(PolynomialFeatures(2,include_bias=False),StandardScaler(),Ridge(alpha=10)),'forest':lambda:RandomForestRegressor(n_estimators=300,max_depth=12,min_samples_leaf=2,random_state=SEED,n_jobs=1)}
def family(r):return 'rectangle' if r['shape'].startswith('rect') else 'L' if r['shape'].startswith('L') else 'circle' if r['shape'].startswith('circle') else r['shape']
def groupid(r):
 sh=r['shape'];period={'rect1':90,'triangle':120,'pentagon':72,'hexagon':60,'circle24':15}.get(sh,180 if sh.startswith('rect') else 360)
 return f"{sh}_{r['area']}_{float(r['orientation'])%period:.6f}_{r['wwr']}"
def score(y,p):
 y=np.asarray(y);p=np.asarray(p)
 return dict(mae=float(mean_absolute_error(y,p)),rmse=float(np.sqrt(mean_squared_error(y,p))),r2=float(r2_score(y,p)),bias=float(np.mean(p-y)),p95_abs_error=float(np.quantile(np.abs(p-y),.95)))
def main():
 rows=read_csv(RES/'simulation_results.csv');assert len(rows)==1890,('Incomplete experiment',len(rows))
 X=np.array([features(r) for r in rows]);y=np.array([float(r['cooling_kwh_th_m2']) for r in rows]);train=np.array([i for i,r in enumerate(rows) if r['group'].startswith('train')]);rect=np.array([i for i in train if rows[i]['group']=='train_rectangle']);test=np.array([i for i,r in enumerate(rows) if r['group'].startswith('test')]);preds=[];metrics=[];timings=[]
 def evaluate(name,scheme,tr,te,fold='all'):
  t=time.perf_counter();m=builders()[name]();m.fit(X[tr],y[tr]);fit=time.perf_counter()-t
  t=time.perf_counter();p=m.predict(X[te]);duration=time.perf_counter()-t
  metrics.append(dict(scheme=scheme,model=name,fold=fold,n_train=len(tr),n_test=len(te),**score(y[te],p)))
  timings.append(dict(scheme=scheme,model=name,fold=fold,fit_seconds=fit,predict_seconds=duration,n_test=len(te)))
  preds.extend(dict(scheme=scheme,model=name,fold=fold,case_id=rows[i]['case_id'],context=rows[i]['context'],group=rows[i]['group'],shape=rows[i]['shape'],product=rows[i]['product'],shade=rows[i]['shade'],actual=y[i],predicted=float(v)) for i,v in zip(te,p))
  return m
 for name in builders():
  cvpred=[];cvactual=[]
  for f,(tr,te) in enumerate(GroupKFold(6).split(X[train],y[train],[groupid(rows[i]) for i in train])):
   assert not set(groupid(rows[i]) for i in train[tr])&set(groupid(rows[i]) for i in train[te])
   evaluate(name,'grouped_cv',train[tr],train[te],str(f))
  for scheme,tr in [('rectangle_transfer',rect),('expanded_transfer',train)]:evaluate(name,scheme,tr,test)
  diagnostic=np.array([i for i,r in enumerate(rows) if r['group'].startswith('diagnostic')])
  evaluate(name,'diagnostic_transfer',train,diagnostic)
  for fam in sorted(set(family(rows[i]) for i in train)):
   tr=np.array([i for i in train if family(rows[i])!=fam]);te=np.array([i for i in train if family(rows[i])==fam]);evaluate(name,'whole_family_holdout',tr,te,fam)
  print('Evaluated',name,flush=True)
 # Pooled CV and external subgroups are descriptive, no tuning on test data.
 pooled=[]
 for scheme in ['grouped_cv','rectangle_transfer','expanded_transfer','whole_family_holdout','diagnostic_transfer']:
  for name in builders():
   rr=[r for r in preds if r['scheme']==scheme and r['model']==name]
   pooled.append(dict(scheme=scheme,model=name,subset='all',n=len(rr),**score([r['actual'] for r in rr],[r['predicted'] for r in rr])))
   if scheme.endswith('transfer'):
    for g in sorted(set(r['group'] for r in rr)):
     ss=[r for r in rr if r['group']==g];pooled.append(dict(scheme=scheme,model=name,subset=g,n=len(ss),**score([r['actual'] for r in ss],[r['predicted'] for r in ss])))
 selected=min([r for r in pooled if r['scheme']=='grouped_cv' and r['model']!='strategy_mean'],key=lambda r:r['mae'])['model']
 model=builders()[selected]();model.fit(X[train],y[train]);
 # Per-context savings, in same units and percentage points.
 effects=[]
 groups={}
 for r in preds:groups.setdefault((r['scheme'],r['model'],r['context']),[]).append(r)
 for (scheme,name,ctx),rr in groups.items():
  base=next(r for r in rr if r['product']=='SN75' and float(r['shade'])==0)
  for r in rr:
   if r is base:continue
   actual=base['actual']-r['actual'];pred=base['predicted']-r['predicted'];rp=100*pred/base['predicted'] if base['predicted']>0 else float('nan');ra=100*actual/base['actual']
   effects.append(dict(scheme=scheme,model=name,context=ctx,case_id=r['case_id'],actual_saving=actual,predicted_saving=pred,actual_reduction_pct=ra,predicted_reduction_pct=rp,saving_abs_error=abs(pred-actual),reduction_abs_error_pp=abs(rp-ra)))
 effsum=[]
 for scheme in sorted(set(r['scheme'] for r in effects)):
  for name in builders():
   rr=[r for r in effects if r['scheme']==scheme and r['model']==name];effsum.append(dict(scheme=scheme,model=name,n=len(rr),saving_mae=float(np.mean([r['saving_abs_error'] for r in rr])),reduction_mae_pp=float(np.mean([r['reduction_abs_error_pp'] for r in rr]))))
 # Physical design results and within-context reduction against SN75/no overhang.
 baselines={r['context']:float(r['cooling_kwh_th_m2']) for r in rows if r['product']=='SN75' and float(r['shade'])==0}
 for r in rows:r['reduction_pct']=100*(baselines[r['context']]-float(r['cooling_kwh_th_m2']))/baselines[r['context']]
 sensitivity=[]
 def key(r):return(r['shape'],float(r['area']),float(r['orientation']),float(r['wwr']),r['product'],float(r['shade']))
 baseidx={key(r):r for r in rows if r['group'].startswith('train')}
 for r in rows:
  if r['group']=='sensitivity':
   b=baseidx[key(r)];sensitivity.append(dict(case_id=r['case_id'],shape=r['shape'],condition=f"ACH{r['ach']}_{r['schedule']}_RH{r['rh']}",product=r['product'],shade=r['shade'],cooling_change=float(r['cooling_kwh_th_m2'])-float(b['cooling_kwh_th_m2']),reduction_change_pp=r['reduction_pct']-b['reduction_pct']))
 zoning=[];circle=[]
 for r in rows:
  if r['group']=='zoning_check':
   b=baseidx[key(r)];zoning.append(dict(case_id=r['case_id'],shape=r['shape'],product=r['product'],shade=r['shade'],single=float(b['cooling_kwh_th_m2']),five=float(r['cooling_kwh_th_m2']),difference_pct=100*(float(r['cooling_kwh_th_m2'])/float(b['cooling_kwh_th_m2'])-1),reduction_difference_pp=r['reduction_pct']-b['reduction_pct']))
  if r['group']=='circle_convergence':
   k=list(key(r));k[0]='circle24';b=baseidx[tuple(k)];circle.append(dict(case_id=r['case_id'],sides=int(r['shape'][6:]),product=r['product'],shade=r['shade'],cooling=float(r['cooling_kwh_th_m2']),relative_to_24_pct=100*(float(r['cooling_kwh_th_m2'])/float(b['cooling_kwh_th_m2'])-1)))
 designrows=[r for r in rows if r['group']=='daylight_application']
 decisions=[]
 for ctx in sorted(set(r['context'] for r in designrows)):
  rr=[r for r in designrows if r['context']==ctx];feas=[r for r in rr if float(r['da300_mean_pct'])>=50];actualbest=min(rr,key=lambda r:float(r['cooling_kwh_th_m2']));best=min(feas,key=lambda r:float(r['cooling_kwh_th_m2'])) if feas else None
  pp=model.predict(np.array([features(r) for r in rr]));pidx={r['case_id']:v for r,v in zip(rr,pp)};chosen=min(feas,key=lambda r:pidx[r['case_id']]) if feas else None
  decisions.append(dict(context=ctx,feasible=len(feas),unconstrained_option=actualbest['product']+'_d'+actualbest['shade'],screened_option=best['product']+'_d'+best['shade'] if best else 'none',predicted_choice=chosen['product']+'_d'+chosen['shade'] if chosen else 'none',regret=float(chosen['cooling_kwh_th_m2'])-float(best['cooling_kwh_th_m2']) if best else '',note='Measured simulated daylight screen, surrogate cooling only. Exploratory 9-point screen, not spatial compliance.'))
 # Actual inference cost with preloaded model, single query and 1000-case batch.
 query=X[test[:1]];t=time.perf_counter()
 for _ in range(100):model.predict(query)
 one=(time.perf_counter()-t)/100
 t=time.perf_counter();model.predict(np.tile(query,(1000,1)));batch=time.perf_counter()-t
 # Domain distance is trained on shape features only, with holdout-context calibration.
 scaler=StandardScaler().fit(X[train,:12]);geo=scaler.transform(X[train,:12]);unique=np.unique(np.round(geo,8),axis=0);nn=NearestNeighbors(n_neighbors=1).fit(unique)
 d=NearestNeighbors(n_neighbors=2).fit(unique).kneighbors(unique)[0][:,1];threshold=float(np.quantile(d,.95))
 artifact=dict(model=model,selected=selected,features=FEATURES,scaler=scaler,nearest=nn,distance_threshold=threshold,training_min=X[train].min(0),training_max=X[train].max(0))
 with (RES/'surrogate.pkl').open('wb') as f:pickle.dump(artifact,f)
 save_csv(RES/'predictions.csv',preds);save_csv(RES/'fold_metrics.csv',metrics);save_csv(RES/'pooled_metrics.csv',pooled);save_csv(RES/'paired_effects.csv',effects);save_csv(RES/'paired_metrics.csv',effsum);save_csv(RES/'sensitivity.csv',sensitivity);save_csv(RES/'zoning_audit.csv',zoning);save_csv(RES/'circle_convergence.csv',circle);save_csv(RES/'design_application.csv',designrows);save_csv(RES/'design_choices.csv',decisions);save_csv(RES/'model_timing.csv',timings)
 summary=dict(n=len(rows),n_training=len(train),n_external=len(test),selected_by_grouped_cv=selected,pooled_metrics=pooled,paired_metrics=effsum,mean_runtime=float(np.mean([float(r['runtime_seconds']) for r in rows])),single_inference_seconds=one,batch1000_seconds=batch,zoning_max_abs_pct=max(abs(r['difference_pct']) for r in zoning),circle48_max_abs_pct=max(abs(r['relative_to_24_pct']) for r in circle if r['sides']==48),design_choices=decisions)
 (RES/'summary.json').write_text(json.dumps(summary,indent=2))
 # Training-size curve is fixed in advance and descriptive, not a tuning loop.
 uniquegroups=sorted(set(groupid(rows[i]) for i in train));rng=np.random.default_rng(SEED);rng.shuffle(uniquegroups);curve=[]
 for count in [24,48,96,len(uniquegroups)]:
  ids=np.array([i for i in train if groupid(rows[i]) in set(uniquegroups[:count])]);m=builders()[selected]();t=time.perf_counter();m.fit(X[ids],y[ids]);fit=time.perf_counter()-t
  curve.append(dict(context_groups=count,n_train=len(ids),fit_seconds=fit,**score(y[test],m.predict(X[test]))))
 save_csv(RES/'learning_curve.csv',curve)
 print('Selected on training CV:',selected,'external n=',len(test),flush=True)
if __name__=='__main__':main()
