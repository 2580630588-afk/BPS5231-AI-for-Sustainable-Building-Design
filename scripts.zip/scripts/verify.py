"""Integrity, shape/surface and reproducibility checks independent of model metrics."""
from pathlib import Path
import sys,json,hashlib,math,collections,re
from experiment import ROOT,RES,RAW,IDF,read_csv,read_idf,polygon,signed,geom,area,design

def main():
 rows=read_csv(RES/'simulation_results.csv');matrix=read_csv(ROOT/'data/design_matrix.csv');assert len(rows)==len(matrix)==1890
 assert len({r['case_id'] for r in rows})==1890
 assert {r['case_id'] for r in rows}=={r['case_id'] for r in matrix}
 train={r['case_id'] for r in rows if r['group'].startswith('train')};test={r['case_id'] for r in rows if r['group'].startswith('test')};assert not train&test
 contexts=collections.Counter(r['context'] for r in rows);assert set(contexts.values())=={6}
 warnings=collections.Counter();geometry=[]
 for r in rows:
  assert int(r['hours'])==8760 and 0<float(r['cooling_kwh_th_m2'])<1000
  obs=read_idf(IDF/(r['case_id']+'.idf'));walls={o[1]:o for o in obs if o[0]=='BuildingSurface:Detailed'}
  floors=[o for o in walls.values() if o[2]=='Floor'];A=sum(area([[float(v) for v in o[k:k+3]] for k in range(12,len(o),3)]) for o in floors)
  assert abs(A-float(r['area']))<1e-4
  for o in walls.values():
   if o[2]=='Wall' and o[6]=='Outdoors':
    pts=[[float(v) for v in o[k:k+3]] for k in range(12,len(o),3)]
    va=[pts[1][j]-pts[0][j] for j in range(3)];vb=[pts[2][j]-pts[1][j] for j in range(3)];normal=[va[1]*vb[2]-va[2]*vb[1],va[2]*vb[0]-va[0]*vb[2],va[0]*vb[1]-va[1]*vb[0]]
    assert abs(normal[2])<1e-6
  err=(RES/'runs'/r['case_id']/'eplusout.err').read_text(errors='replace');assert '** Severe **' not in err and '**  Fatal  **' not in err
  for line in err.splitlines():
   if '** Warning **' in line:warnings[line.strip()]+=1
 if (RES/'predictions.csv').exists():
  pr=read_csv(RES/'predictions.csv')
  for scheme in ['grouped_cv','rectangle_transfer','expanded_transfer','whole_family_holdout']:
   for model in ['strategy_mean','interpolation','ridge','forest']:
    rr=[r for r in pr if r['scheme']==scheme and r['model']==model];assert len(rr)==len({r['case_id'] for r in rr})
    assert len(rr)==(1008 if scheme in ['grouped_cv','whole_family_holdout'] else 384)
 report={'passed':True,'cases':1890,'train_cases':len(train),'external_cases':len(test),'paired_contexts':len(contexts),'severe_errors':0,'warnings':dict(warnings),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in RAW.iterdir() if p.suffix in ['.idf','.epw']},'note':'Simulation consistency is not empirical validation.'}
 (RES/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
