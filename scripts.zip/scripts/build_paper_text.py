"""Generate final paper text from completed result tables."""
from pathlib import Path
import json
from experiment import ROOT,RES,read_csv
S=json.loads((RES/'summary.json').read_text(encoding='utf-8-sig')); A=json.loads((RES/'additional_analysis.json').read_text(encoding='utf-8-sig'))
M=read_csv(RES/'pooled_metrics.csv'); refs=json.loads((ROOT/'references.json').read_text(encoding='utf-8-sig'))
def metric(s,m='ridge'):
    return next(r for r in M if r['scheme']==s and r['model']==m and r['subset']=='all')
table='| Model | Grouped CV | External | Family holdout |\n| :--- | ---: | ---: | ---: |\n'
for m,label in [('strategy_mean','Strategy mean'),('interpolation','5-NN interpolation'),('ridge','Polynomial Ridge'),('forest','Random forest')]:
    table+='| '+label+' | '+' | '.join(f"{float(metric(s,m)['mae']):.2f}" for s in ['grouped_cv','expanded_transfer','whole_family_holdout'])+' |\n'
paper=f'''# Rapid Evaluation of Office Window Options in Singapore: Prediction Transfer and Design Applicability across Plan Shapes

**BPS5231 AI for Sustainable Building Design — Final study**
*30 October 2026*

## Abstract

This study tests whether a fast surrogate estimates office cooling demand and paired window-strategy savings beyond familiar geometries. A reproducible EnergyPlus 24.2 experiment comprises 1,890 annual simulations covering rectangles, L-shaped plans, equilateral triangles, regular pentagons and hexagons, and polygonal approximations of circles. Three documented glazing assemblies and two overhang depths give six paired options. The initial experiment uses 1,008 development cases and reserves 384 external cases. Another 252 diagnostic cases separate geometry changes from simultaneous orientation and window-to-wall-ratio changes. Polynomial Ridge, selected using grouped development cross-validation, achieves external cooling MAE of 0.47 kWh thermal/(m² year) and savings-rate MAE of 0.45 percentage points. Forest predictions transfer less successfully under combined input shifts. Operation changes alter percentage savings, while a representative daylight screen changes the preferred glazing at low window area. A local interface displays predictions, matching simulations and applicability warnings. The contribution is a bounded design-assessment workflow, not a novel learning algorithm or real-building validation.

**Keywords:** office windows; cooling thermal demand; surrogate model; geometric transfer; daylight screening; reproducibility

## 1 Introduction and related work

Early design involves repeated comparisons between floor plans and facade options. Two distinct questions arise: whether a model predicts absolute demand on an unfamiliar plan, and whether intervention savings transfer accurately. A small error in total demand does not guarantee an accurate difference between two similar options. Moreover, an intervention with minimum cooling demand may have undesirable daylight performance.

Surrogates already approximate retrofit solutions [9]. Qiblawi et al. [5] investigate geometry changes and show that good prediction does not always imply out-of-sample generalisation. Jowett-Lockwood and Evins [6] examine different geometries and locations for inverse surrogates, which address a different task from the forward prediction here. Westermann and Evins [7] use uncertainty-aware surrogates to identify cases that merit simulation. Our geometric-distance warning is a novelty heuristic, not their Bayesian uncertainty method.

This study asks: how do demand and intervention effects transfer across shapes and areas; how do operating assumptions affect the results; and when does rapid prediction support a useful design comparison? A simple regularised response surface remains a valid preferred model. Algorithmic complexity is not itself a contribution.

## 2 Simulation and experiment

### 2.1 Geometry and thermal assumptions

The open Buildings.sg office template and Singapore IWEC weather are retained with attribution and hashes [1,4]. Final cases rebuild the geometry as a single well-mixed open-plan zone, height 3 m, with adiabatic floors and ceilings. This consistent simplification replaces the interim five-zone model. The previous 144 outcomes are not combined with the final training data. A separate matched five-zone experiment audits the zoning change.

Opaque assemblies use the source library's Generic Exterior Wall, Generic Interior Floor and Generic Roof, documented layer by layer in data/opaque_constructions.json. They are controlled assumptions, not calibrated Singapore office constructions. No urban obstruction, infiltration, bulk interzone airflow or detailed HVAC electricity model is added. Floor-area and window-area checks operate on generated surface coordinates.

The main L outline uses (0,0), (3,0), (3,1), (1,1), (1,3), (0,3), scaled to the target area. Its external-test variant has arm thickness 1.3. Concave floors and roofs are triangulated within the same zone. The other nonrectangular shapes are regular polygons. The circle is an equal-area 24-gon, with 12- and 48-gon convergence tests. It has planar window segments rather than detailed curved glass. Each wall has a centred window whose width and height scale with the square root of WWR. Horizontal overhangs extend from the window head and rotate with the building.

![Plan families](../results/figures/plan_shapes.png)

**Figure 1.** Representative 900 m² plans on a common scale. The experiment covers these families, not arbitrary architectural geometry.

### 2.2 Products and operation

The Guardian 2025 selector [3] supplies linked parameters for 6-16-4 double glazing with 90% argon: SN75 (U=1.0 W/(m² K), g=0.40, VT=0.75), SN70/35 (1.0, 0.35, 0.70), and SN40/23 (1.0, 0.23, 0.40). Each has no overhang or a 0.6 m overhang. The common baseline is SN75 without shading. Catalog g is used as nominal SHGC in SimpleGlazing; this does not reproduce full layer-level angular optics, frames or certified whole-window properties, and does not establish local supply or price.

Ideal loads use unlimited capacity, cooling at 26°C, heating at 20°C and humidistat targets of 40%–70% RH. Lighting is 9 W/m², equipment 22 W/m² and design occupancy 0.047501 persons/m². The inherited weekday 09:00–18:00 fractional occupancy profile has unoccupied weekends. Outdoor air is 0.6 ACH with occupancy scheduling and heat recovery disabled. Daylight dimming is off. The IWEC input uses the non-leap 2006 calendar and represents typical rather than observed study-year weather.

### 2.3 Dataset roles

| Dataset | Cases | Purpose |
| :--- | ---: | :--- |
| Rectangle development | 648 | Ratios 1, 2, 4; areas 600, 900, 1200 m² |
| Other-family development | 360 | Five nonrectangular families at 900 m² |
| Prespecified external tests | 384 | New ratios, areas and combinations |
| Operation sensitivity | 180 | Five one-factor changes on six forms |
| Circle convergence | 12 | 12- and 48-gon tests |
| Daylight application | 36 | Six representative contexts |
| Zoning comparison | 18 | One- versus five-zone rectangles |
| Post-hoc diagnostics | 252 | Shape-only and area-only changes |

**Table 1.** Final experiment, 1,890 simulations. Each context contains six paired options; rows are not independent measured buildings.

Development orientations are 0°, 45°, 90° and 135°, with WWR 0.2, 0.4 and 0.6. The 384 external cases use orientations 15° and 75° and WWR 0.3 and 0.5. They cover ratios 1.5/3, ratio 5 extrapolation, rectangular areas 750/1050/1500 m², and nonrectangular areas 750/1050 m². These are combined shifts, not isolated shape tests. After the initial evaluation, 144 matched-area shape tests and 108 matched-shape area tests were added. These explicitly post-hoc diagnostics never enter training or tuning. The machine-readable protocol distinguishes both stages.

## 3 Analysis methods

### 3.1 Outcomes and model evaluation

Cooling intensity is q = ΣQ/(3.6 × 10⁶ A), where Q is hourly Zone Ideal Loads Supply Air Total Cooling Energy in joules, summed across thermal zones, and A is floor area in m² [2]. This is supply-air cooling thermal demand under the stated conditions, not electricity, measured EUI or money saved. Paired saving is Δq = q baseline − q option; reduction is R = 100Δq/q baseline. Predictions use the same formulas with predicted baseline and option demand. Demand and saving errors use kWh thermal/(m² year); reduction errors use percentage points.

Features comprise log area, external-wall/floor-area ratio, compactness 4πA/P², footprint/bounding-box-area ratio, eight perimeter-weighted directional exposure descriptors, WWR, U, SHGC, VT and overhang depth. Geometry is described physically rather than by an arbitrary numeric family label. Linked product values and constant U prevent independent causal attribution to U, SHGC and VT.

Fixed models are a strategy-specific training mean, standardised inverse-distance five-neighbour interpolation, degree-two Polynomial Ridge with training-fold scaling and alpha 10, and random forest with 300 trees, depth 12, minimum leaf size 2 and seed 2026. Ridge is a regularised response surface, not evidence that sophisticated AI is necessary.

Six-fold grouped cross-validation keeps the six strategies together and combines rotationally equivalent regular-shape contexts. Whole-family holdout excludes each of the six families in turn. Rectangle-only and expanded training sets separately predict the same external cases. Model selection uses grouped development MAE only. Preprocessing is fitted within training folds [8]. Prediction and paired-effect metrics are reported independently.

### 3.2 Sensitivity and daylight screen

Sensitivity tests at 900 m², 0° and WWR 0.4 separately change ventilation to 0.3/1.2 ACH, operation to 07:00–20:00 at fraction 0.75, maximum RH to 60%, or humidity control to None. The schedule experiment changes both duration and occupancy profile. Ranges are exploratory rather than regulatory, and interactions are not estimated. The five-zone bridge matches opaque assemblies and operation, removes domestic-hot-water zone gains, and retains 3 m perimeter zones in three rectangles.

For the representative 2:1 rectangle, EnergyPlus SplitFlux calculates nine reference points at 10%, 50% and 90% of both dimensions, 0.8 m above the floor. Lighting-control fractions are zero. The illustrative screen requires mean point DA300 of at least 50% of occupied weekday hours. Nine equally weighted points do not constitute spatial daylight autonomy, glare evaluation or compliance. Daylight is available for two orientations and three WWRs only.

## 4 Results and design implications

### 4.1 Absolute prediction and effect transfer

{table}

**Table 2.** Pooled cooling-demand MAE. External results use 384 combined-shift cases; whole-family holdout covers the 1,008 development cases under separate splits.

Ridge achieves external MAE 0.47, RMSE 0.63 and R² 0.995. Interpolation MAE is 1.89 and forest MAE 5.36. The external WWRs lie between development levels, challenging the forest's stepwise response. Post-hoc matched tests reduce forest MAE to 0.86, while Ridge gives 0.37, including 0.43 for shape-only and 0.28 for area-only changes. This supports the relevance of combined shifts but does not isolate one variable as the sole explanation.

Rectangle-only Ridge has external MAE 0.48, close to expanded Ridge at 0.47. Thus more shape families do not yield a large aggregate improvement in this controlled system. Whole-family Ridge MAE rises to 1.28. External WWRs also span a narrower interval, so external error below grouped-CV error does not imply universally easy transfer.

![Prediction errors](../results/figures/prediction_comparison.png)

**Figure 2.** Model comparisons under grouped and external testing. Complexity does not automatically improve transfer.

Expanded Ridge savings MAE is 0.64 and reduction-rate MAE 0.45 percentage points, versus interpolation at 1.99 and 1.40. On grouped validation, forest predicts differences more accurately than Ridge despite worse absolute-demand MAE. This demonstrates why the outcomes must remain separate. A paired-context bootstrap gives Ridge-minus-interpolation demand MAE difference {A['bootstrap_mae_difference_vs_interpolation']:.2f}, with descriptive 95% interval [{A['bootstrap_context_95pct_interval'][0]:.2f}, {A['bootstrap_context_95pct_interval'][1]:.2f}]. Resampling 64 simulated contexts does not quantify real-building uncertainty.

### 4.2 Sensitivity and geometric checks

Ventilation of 0.3 ACH reduces cooling intensity by about 15 units; 1.2 ACH adds about 30. The extended occupancy profile adds about 40 kWh thermal/(m² year). Saving percentages shift by up to {A['sensitivity_max_abs_reduction_change_pp']:.2f} percentage points as operating loads change the baseline. Humidity-control changes have much smaller effects in this ideal-loads configuration, which does not establish that tropical humidity or real dehumidification electricity is unimportant.

![Sensitivity](../results/figures/sensitivity.png)

**Figure 3.** Operation changes affect demand and the denominator of percentage savings. The longer schedule also changes occupancy intensity.

The matched single-/five-zone tests differ by at most {A['zoning_max_abs_pct']:.2f}% in cooling and {A['zoning_max_reduction_difference_pp']:.2f} percentage points in paired reductions. This is a rectangle-only audit, not proof of adequate zoning for every irregular occupied building. The 24-/48-gon cooling difference is at most {A['circle48_max_abs_pct']:.2f}% across six options at the reference context. Circle convergence is therefore bounded to that context.

### 4.3 A constrained design comparison

At 900 m², aspect ratio 2, 0° and WWR 0.2, SN40/23 plus a 0.6 m overhang minimises cooling at 99.45 kWh thermal/(m² year), but mean DA300 is 36.90%. Under the declared 50% screen, SN70/35 with the overhang becomes the lowest-demand feasible option: 102.77, with DA300 77.46%. It sacrifices about 3.31 thermal units per m² per year to pass the illustrative daylight screen. At WWR 0.4/0.6, the darkest shaded option passes.

![Daylight comparison](../results/figures/daylight_tradeoff.png)

**Figure 4.** Cooling versus sampled daylight in 36 rectangle cases. The horizontal line is a study screen, not a code threshold.

The constrained choice changes in two of six contexts. Surrogate and simulation choices agree, but these thermal contexts already occur in development data and daylight comes from simulation. Zero regret here demonstrates workflow consistency, not independent AI decision accuracy. There is no cost optimum, payback calculation or lighting-energy saving claim.

### 4.4 Speed, learning curve and interface

Nine sequential simulations across rectangle, L and circle cases have median runtime {A['sequential_simulation_median_seconds']:.2f} s. A preloaded Ridge prediction takes about {A['single_prediction_seconds']*1000:.3f} ms on this workstation, excluding interface latency. Assuming the same median for every training case gives an illustrative data-generation cost of {A['conservative_training_cost_seconds']/60:.1f} minutes and break-even near {A['approx_break_even_queries']:.0f} additional individual-case queries. Validation, development and engineering costs increase total effort. A few one-off designs remain inexpensive to simulate directly.

The fixed learning curve gives external MAE 1.27/0.66/0.45/0.47 for 168/360/678/1008 training rows. More data do not improve accuracy monotonically. These are descriptive fixed-subset evaluations, not external-test tuning.

The local interface compares two forms and six window options, reporting predicted cooling, implied total demand and percentage reductions. Matching simulation values appear separately. Daylight appears only for supported contexts. Explicit bounds and a training-geometry distance rule flag possible extrapolation; the distance rule flags {A['domain_flagged']} of {A['domain_total']} external rows. It is not a calibrated error probability. Changed operation or unresolved project conditions require new simulation.

## 5 Reproducibility and limitations

The inspected interim branch lacked a results directory despite the README requiring it. The final local package contains generated IDFs, compact run records and logs, input and result tables, pinned dependencies, an executed notebook, model, interface and reproduction commands. Full reproduction requires EnergyPlus 24.2; quick reproduction starts with bundled outcomes. Large intermediate SQL files are regenerated. Hashes support integrity checks. No GitHub upload has been made.

All 1,890 simulations have 8,760 hours and no severe errors. Unused-construction warnings are disclosed. The bridge retains inherited schedule-type warnings; daylight cases warn about omitted glare and zero controlled-light fractions, consistent with the declared scope. Successful execution does not validate physical accuracy.

Limits include one climate, selected regular polygons and two L outlines, well-mixed open-plan zones, assumed envelope assemblies, fixed operation, three linked products, nominal glazing optics and a sparse rectangle-only daylight screen. Tests omit arbitrary concave geometry, atria, partitions, urban shading, detailed HVAC, costs and embodied impacts. Small simulation runtimes limit the practical advantage for isolated tasks. These bounds prevent interpreting the interface as a universal design or compliance tool.

## 6 Conclusions

A regularised response surface provides accurate demand and savings estimates within this controlled experiment. Complex models are not automatically better, and adding more shape families produces only a small aggregate Ridge improvement. Operating assumptions affect saving percentages. A declared daylight screen creates a concrete design tradeoff at low WWR. The defensible application is repeated preliminary comparison with explicit limits and access to simulation, not universal facade recommendations or real-building electricity prediction.

## References

'''
paper+='\n\n'.join(f"**[{r['id']}]** {r['citation']} [Source]({r['url']})" for r in refs)
(ROOT/'deliverables/final_paper_editable.md').write_text(paper,encoding='utf-8')
print('Final paper source:',len(paper.split()),'words')
if (ROOT/'results/final_validation/summary.json').exists():
 from update_validation_report import main as add_followup
 add_followup()
