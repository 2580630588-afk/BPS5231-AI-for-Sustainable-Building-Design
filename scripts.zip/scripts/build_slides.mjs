import fs from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const tmp=process.env.BUILD_DIR||path.join(root,'build');await fs.mkdir(tmp,{recursive:true});
const S=JSON.parse(await fs.readFile(path.join(root,'results/summary.json'),'utf8'));
const refs=JSON.parse(await fs.readFile(path.join(root,'references.json'),'utf8'));
const csv=async(file)=>{const lines=(await fs.readFile(path.join(root,file),'utf8')).replace(/^\uFEFF/,'').trim().split(/\r?\n/).map(x=>x.split(','));return lines.slice(1).map(r=>Object.fromEntries(lines[0].map((k,i)=>[k,r[i]])));};
const rows=await csv('results/simulation_results.csv'),folds=await csv('results/fold_metrics.csv');
const G='within_shape_context_holdout',H='leave_one_shape_out';
const val=(scheme,model,key='mae')=>S.pooled_metrics.find(x=>x.scheme===scheme&&x.model===model&&x.subset==='all')[key];
const allrefs=refs.map(r=>`[${r.id}] ${r.citation}\n${r.url}`).join('\n\n');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const N='#173247',T='#087F8C',O='#B86A32',GRAY='#607080',BG='#FFFFFF';
function text(s,t,x,y,w,h,size=28,color=N,bold=false){const sh=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});sh.text=t;sh.text.style={typeface:'Arial',fontSize:size,color,bold,autoFit:'none'};return sh;}
function slide(title,note,foot=''){const s=p.slides.add();s.background.fill=BG;text(s,title,60,40,1160,77,40,N,true);if(foot)text(s,foot,60,643,1115,60,18,GRAY);text(s,String(p.slides.items.length),1190,664,40,27,18,GRAY);return s;}
function table(s,values,{y=170,h=330,widths=null,size=25,x=60,w=1160}={}){const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:w,height:h,values,columnWidths:widths??Array(values[0].length).fill(w/values[0].length)});for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){const z=t.getCell(r,c);z.fill=r===0?N:r%2===0?'#F0F5F6':BG;z.text.style={typeface:'Arial',fontSize:size,color:r===0?BG:N,bold:r===0};}return t;}
function bar(s,categories,series,{y=172,h=415,ylab='Cooling [kWh thermal/m²/year]',max=undefined,x=65,w=1135}={}){return s.charts.add('bar',{position:{left:x,top:y,width:w,height:h},categories,series:series.map(q=>({...q,values:q.values.map(v=>+Number(v).toFixed(5))})),barOptions:{direction:'column',grouping:'clustered',gapWidth:60},hasLegend:series.length>1,legend:{position:'bottom',textStyle:{typeface:'Arial',fontSize:20,fill:N}},xAxis:{textStyle:{typeface:'Arial',fontSize:20,fill:N}},yAxis:{title:{text:ylab,textStyle:{typeface:'Arial',fontSize:20,fill:N}},min:0,max,numberFormatCode:'0.0',textStyle:{typeface:'Arial',fontSize:19,fill:GRAY},majorGridlines:{fill:'#E3EAED',width:.5}},chartFill:BG,chartLine:{fill:'none',width:0}});}
const NR=JSON.parse(await fs.readFile(path.join(root,'results/nonrect_daylight/summary.json'),'utf8'));
const ND=await csv('results/nonrect_daylight/decisions.csv');
const A=JSON.parse(await fs.readFile(path.join(root,'results/additional_analysis.json'),'utf8'));
function img(s,file,x,y,w,h){s.images.add({blob:new Uint8Array(readFileSync(path.join(root,file))),contentType:'image/png',alt:file,fit:'contain',position:{left:x,top:y,width:w,height:h}});}
let s=slide('Office window design across plan shapes','','BPS5231 Final Study   19 November 2026   Cooling thermal demand, not electricity');
text(s,'Fast estimates,\nexplicit limits',60,149,530,145,54,N,true);
text(s,'Performance on unseen forms\nTransfer of intervention savings\nA daylight-constrained design example',60,350,520,147,29,T);
img(s,'results/figures/plan_shapes.png',610,160,610,360);
text(s,'2,040 annual records, including a 120-run daylight extension',60,559,1140,55,32,N,true);

s=slide('A reproducible experiment with separate test roles','','Inputs and results are included. Source model: Buildings.sg [1]. Product data: Guardian 2025 [3].');
table(s,[['Dataset','Cases','Role'],['Development','1,008','Rectangles plus five other shape families'],['Prespecified external','384','New ratios, areas, orientation and WWR'],['Robustness audits','210','Operation, zoning and circle discretisation'],['Daylight application','36','Six representative rectangular contexts'],['Post-hoc diagnostics','252','Separate shape-only and area-only changes'],['Independent follow-up','30','Four new daylight contexts and 600 m² L form'],['Nonrectangular daylight','120','60 primary cases + 60 sampling-audit repetitions']],{y:137,h:360,widths:[345,145,670],size:22});
text(s,'Six paired options per context: three documented glass assemblies × two overhangs.\nGrouped CV keeps paired and rotationally equivalent cases together.\nWhole-family holdouts and untouched external tests assess different transfer questions.',60,516,1140,111,26,T,true);

s=slide('Prediction transfer favours a simple response surface','','MAE: kWh thermal/(m² year). Model selection uses development CV only. No tuning on external tests.');
bar(s,['Strategy mean','5-NN interpolation','Polynomial Ridge','Random forest'],[{name:'Grouped CV',fill:'#687B8C',values:['strategy_mean','interpolation','ridge','forest'].map(m=>val('grouped_cv',m))},{name:'External test',fill:T,values:['strategy_mean','interpolation','ridge','forest'].map(m=>val('expanded_transfer',m))}],{y:140,h:370,ylab:'Cooling-demand MAE',max:11});
text(s,'Ridge: 0.47 external MAE and 0.45 percentage-point savings-rate MAE.\nShape/area-only diagnostic MAE: Ridge 0.37, forest 0.86.',60,550,1140,81,29,T,true);

s=slide('Savings depend on operating assumptions','','One-factor tests across six shapes. The extended schedule changes hours and occupancy fraction.');
table(s,[['Change from baseline','Cooling intensity change','Savings-rate change'],['Ventilation 0.3 ACH','About −15','Up to +2.21 pp'],['Ventilation 1.2 ACH','About +30','Down to −3.38 pp'],['Longer occupancy profile','About +40','Down to −4.04 pp'],['RH 60% / controls off','Small in this setup','Within about 0.34 pp']],{y:153,h:315,widths:[450,355,355],size:25});
text(s,'Geometry audits',60,508,1150,40,29,N,true);
text(s,`Matched one-/five-zone rectangles: maximum demand difference ${A.zoning_max_abs_pct.toFixed(2)}%.\nCircle 24-/48-side comparison: maximum difference ${A.circle48_max_abs_pct.toFixed(2)}% at one context.`,60,559,1150,73,27,T);

s=slide('Nonrectangular daylight changes window choices','','850 m², 30°, five shapes. Area-weighted DA300 ≥50% is a study screen; no glare or compliance claim.');
const names={Lwide:'Wide-arm L',triangle:'Triangle',pentagon:'Pentagon',hexagon:'Hexagon',circle24:'Circle (24-gon)'};
const choose=(shape,w)=>ND.find(r=>r.shape===shape&&+r.wwr===w&&+r.grid_spacing===4).simulation_best.replace('SN7035','SN70/35').replace('SN4023','SN40/23');
table(s,[['Shape','Best at 20% WWR','Best at 40% WWR'],...Object.entries(names).map(([shape,label])=>[label,choose(shape,.2),choose(shape,.4)])],{y:140,h:294,widths:[360,400,400],size:25});
text(s,`Daylight changes ${NR.choices_changed_by_daylight}/10 cooling-only choices.`,60,459,1150,48,31,T,true);
text(s,`Model matches ${NR.model_correct}/10 feasible optima; the simple rule matches ${NR.rule_correct}/10.\nAt triangle WWR 20%, the model reduces simulated cooling by 0.208 versus the rule.\n60 primary cases: MAE ${NR.primary_mae.toFixed(2)}. Grid audit: ${NR.grid_choice_changes}/10 choices change.`,60,522,1150,111,23);

s=slide('Local comparison interface with applicability warnings','','Run: python app/serve.py   Open http://127.0.0.1:8765/   No GitHub upload or public hosting.');
img(s,'results/interface_preview_english.png',60,129,720,490);
text(s,'Compare two shapes\nand six window options',825,147,395,83,29,T,true);
text(s,'Separate predictions and\nsimulation results.\nWarnings for extrapolation.\nDaylight only where tested.',825,258,395,160,24);
text(s,`Median simulation: ${A.sequential_simulation_median_seconds.toFixed(2)} s\nPrediction: ${(A.single_prediction_seconds*1000).toFixed(3)} ms\n\nIncluding training simulations:\nrough break-even ≈1,008 queries.`,825,449,395,175,23,N,true);

s=slide('Conclusions and limits','','Key references: Qiblawi et al. (2026), Jowett-Lockwood & Evins (2025), Westermann & Evins (2021). Full references in paper.');
text(s,'Supported by this experiment',60,151,1140,42,31,T,true);
text(s,'A regularised response surface predicts demand and paired savings well.\nOperation assumptions change the reported percentage benefit.\nIn 10 nonrectangular contexts, the model selects 10 optima and the simple rule selects 9.',60,211,1140,130,29);
text(s,'Use for repeated preliminary comparisons',60,388,1140,43,31,T,true);
text(s,'Single climate, simplified open-plan zones and selected geometric families.\nNonrectangular daylight at one area and orientation. No cost or HVAC electricity.\nNew project conditions still require simulation and professional checks.',60,449,1140,130,29);
text(s,'Delivered: paper, editable slides, executed notebook, complete results and local app.',60,593,1140,40,24,N,true);

const candidate=path.join(tmp,'candidate.pptx');await(await PresentationFile.exportPptx(p)).save(candidate);
const {execFileSync}=await import('node:child_process');execFileSync(process.env.RUNTIME_PYTHON,[path.join(root,'scripts/remove_pptx_notes.py'),candidate]);
const skill=process.env.PRESENTATION_SKILL_DIR;
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
await finalizePresentation({workspaceDir:process.env.WORKSPACE_DIR,candidatePath:candidate,finalPath:path.join(root,'deliverables/final_slides_english_interface.pptx'),pythonExecutable:process.env.RUNTIME_PYTHON,integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...[2,4,5].flatMap(n=>['--require-native-table-slide',String(n)])],explicitTotalSlideCount:7,requiredNativeTableOwnerSlides:[2,4,5],requiredNativeChartOwnerSlides:[3],fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,materializeLiteralChartWorkbooks:true,receiptPath:path.join(tmp,'validation.json')});
const {FileBlob}=await import('@oai/artifact-tool');const final=await PresentationFile.importPptx(await FileBlob.load(path.join(root,'deliverables/final_slides_english_interface.pptx')));
await fs.mkdir(path.join(tmp,'previews'),{recursive:true});for(let i=0;i<final.slides.items.length;i++){const blob=await final.export({slide:final.slides.items[i],format:'png',scale:1});await fs.writeFile(path.join(tmp,'previews',`slide-${i+1}.png`),new Uint8Array(await blob.arrayBuffer()));}
console.log('Saved and rendered final seven-slide deck without notes.');
